--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: locations; Type: TABLE; Schema: public; Owner: admin; Tablespace: 
--

CREATE TABLE locations (
    id integer NOT NULL,
    name character varying(512) NOT NULL,
    category character varying(512) NOT NULL,
    subcategory character varying(512) DEFAULT ''::character varying NOT NULL,
    latitude double precision NOT NULL,
    longitude double precision NOT NULL,
    address character varying(512) NOT NULL,
    opening character varying(512) DEFAULT 'Mon, Tue, Wed, Thu, Fri, Sat: 0800-2030.'::character varying NOT NULL,
    closing character varying(512) DEFAULT '01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .'::character varying NOT NULL,
    tel character varying(512) DEFAULT ''::character varying NOT NULL,
    note character varying(512) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE locations OWNER TO admin;

--
-- Name: locations_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE locations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE locations_id_seq OWNER TO admin;

--
-- Name: locations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE locations_id_seq OWNED BY locations.id;


--
-- Name: suggest; Type: TABLE; Schema: public; Owner: admin; Tablespace: 
--

CREATE TABLE suggest (
    id integer NOT NULL,
    msg character varying(1024) NOT NULL,
    category character varying(32) NOT NULL,
    email character varying(64)
);


ALTER TABLE suggest OWNER TO admin;

--
-- Name: suggest_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE suggest_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE suggest_id_seq OWNER TO admin;

--
-- Name: suggest_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE suggest_id_seq OWNED BY suggest.id;


--
-- Name: waiting; Type: TABLE; Schema: public; Owner: admin; Tablespace: 
--

CREATE TABLE waiting (
    id integer NOT NULL,
    name character varying(512) NOT NULL,
    category character varying(512) NOT NULL,
    subcategory character varying(512) DEFAULT ''::character varying NOT NULL,
    latitude double precision NOT NULL,
    longitude double precision NOT NULL,
    address character varying(512) NOT NULL,
    opening character varying(512) DEFAULT ''::character varying NOT NULL,
    closing character varying(512) DEFAULT '01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .'::character varying NOT NULL,
    tel character varying(512) DEFAULT ''::character varying NOT NULL,
    note character varying(512) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE waiting OWNER TO admin;

--
-- Name: waiting_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE waiting_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE waiting_id_seq OWNER TO admin;

--
-- Name: waiting_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE waiting_id_seq OWNED BY waiting.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY locations ALTER COLUMN id SET DEFAULT nextval('locations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY suggest ALTER COLUMN id SET DEFAULT nextval('suggest_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY waiting ALTER COLUMN id SET DEFAULT nextval('waiting_id_seq'::regclass);


--
-- Data for Name: locations; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY locations (id, name, category, subcategory, latitude, longitude, address, opening, closing, tel, note) FROM stdin;
1	K1 Academy and Muscle Club	palestra		44.0490679999999983	12.5613050000000008	Via Vega, 50 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0930-1230, 1530-1900. Fri: 0830-1500. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 775154	
2	Mantra Wellness Club	palestra		44.0825060000000022	12.5464950000000002	Viale Paolo Toscanelli, 12 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0830-1330, 1530-1930.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 733772	
3	Rimini Clinique Body Building Associaz.Sportiva E Culturale	palestra		44.0704440000000019	12.5656130000000008	Via S. Giovanni, 7 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0830-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 782152	
5	Futura Centro Danza and Fitness	palestra		44.0573049999999995	12.5526450000000001	Via Giovanni Beltrame, 2 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0900-1500. Fri: 0900-1630.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 778560	
6	C.u.s. Bologna A.s.d	palestra		44.0615779999999972	12.56968	Via Carlo Cattaneo, 17 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0830-1230, 1530-1900.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 485930	
7	Palestra New Magic Body	palestra		44.0550890000000024	12.565626	Via Melozzo da Forlì, 18 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0930-1230, 1530-2000.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 782310	
8	Palestra Steven Sporting Club	palestra		44.0437299999999965	12.5610169999999997	Via Circonvallazione Nuova, 57 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0930-1930. Fri: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 778878	
9	Palestra Wellness Club	palestra		44.0589900000000014	12.5625210000000003	Via Dario Campana, 3 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0930-1230, 1500-2000.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 787167	
10	Figurella Aurora Srl	palestra		44.0644350000000031	12.4487089999999991	Via Giuseppe Mazzini, 16 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0930-1230, 1500-1930. Fri: 0900-1800.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 623792	
12	Associazione Sportiva Activa Centro Fitness - Palestra 	palestra		44.0663049999999998	12.4415379999999995	Via Andrea Costa, 98 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat:0930-1200, 1500-1930.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 622794	
13	New Gimnasium - Palestra 	palestra		43.9996980000000022	12.6514389999999999	Viale Giuseppe Mazzini, 26 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0830-1900.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 602732	
14	Polisportiva Comunale Riccione	palestra		44.0344529999999992	12.5792929999999998	Viale Forlimpopoli, 15 - Riccione Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0830-1930.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 643559	
15	Cipriani Training - Gruppo Pesisti Riminese	palestra		44.0405709999999999	12.2657290000000003	Via Arnaldo da Brescia, 8 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0800-1900.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 232243	
17	Schilling Squash and Gym	palestra		44.0422470000000033	12.5876169999999998	Via Antonio Draghi, 12 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0930-1330, 1530-1930. Fri: 0930-1630.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 386711	
18	Associazione Sport E Salute	palestra		44.0626480000000029	12.5697340000000004	Via Guglielmo Oberdan, 34 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0830-1530.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 21262	
19	NEW BODY CLUB	palestra		44.0379969999999972	12.5975420000000007	Via De Garattoni, 2e - Santarcangelo di Romagna Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0930-1800. Fri:0900-1900.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 621815	
20	New Aerobic Studios	palestra		44.0379620000000003	12.5975400000000004	Viale Gabriele D'Annunzio, 133 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0830-1230, 1530-1930.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 645817	
21	ASD Atelier Pilates - Rimini	palestra		44.0541759999999982	12.5568249999999999	Via di Mezzo, 39 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0830-1900.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	347 925 1280	
22	sport village	palestra		44.0679620000000014	12.5523520000000008	Via Aquileia, 14 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 1000-1830. Fri:0900-1900.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 741030 	
23	Natura Sì Bologna	supermarket		44.4950490000000016	11.314387	Via Montefiorino, 2/D 40134 Bologna	Tue, Wed, Thu, Sat: 0900-1930. Mon: 1400-2000. Fri: 0900-2000.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051/6144011	
24	Natura Sì Bologna	supermarket		44.4793540000000007	11.3810409999999997	Via Po, 3 40139 Bologna	Tue, Wed, Thu, Sat: 0900-1930. Mon: 1400-2000. Fri: 0900-2000.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051/6241205	
25	CONAD	supermarket		44.4944599999999966	11.3471759999999993	Via San Vitale 1 - Bologna BO	Mon, Tue, Thu, Fri: 0800-1300, 1600-1930. Wed: 0800-1300. Sat: 0800-1930.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051/561705	
26	Esselunga Santa Viola	supermarket		44.5084760000000017	11.2946399999999993	Via Emilia Ponente, 72 - Bologna, BO	Tue, Wed, Thu, Fri, Sat: 0800-2100. Mon: 1200-2100.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 310781	
27	Esselunga San Vitale	supermarket		44.4921470000000028	11.3846869999999996	Via Guelfa - Bologna, BO	Tue, Wed, Thu, Fri, Sat: 0800-2100. Mon: 1200-2100.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 6010727	
28	Esselunga Casalecchio Di Reno	supermarket		44.4824470000000005	11.2707800000000002	Piazza Degli Etruschi, 2 - Casalecchio Di Reno, BO	Tue, Wed, Thu, Fri, Sat: 0800-2100. Mon: 1200-2100.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 6132544	
29	CONAD	supermarket		44.5238769999999988	11.3208760000000002	Via Della Ca' Bianca 5 - Bologna BO	Mon, Tue, Wed, Thu, Fri, Sat: 0800-1930.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051/6341703	
30	CONAD	supermarket		44.5083800000000025	11.2976930000000007	Via Speranza 52 - Bologna BO	Mon, Tue, Wed, Thu, Fri, Sat: 0800-1930.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051/6190116	
11	La Fraternita' Soc.Coop.Sociale A R.L. - Palestra A.G.23 	palestra		44.0319870000000009	12.5620239999999992	Via del Lavoro, 64 - Rimini RN	Mon, Tue, Wed, Thu, Fri, 0930-1230, 1430-1900. Fri: 0900-1800.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 621488	
16	RiminiWellness	palestra		44.0405709999999999	12.2857289999999999	Via Emilia, 155 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0800-1230, 1530-1930.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 744618	
31	CONAD	supermarket		44.484062999999999	11.3734649999999995	Via Emilia Levante 6-5 - Bologna BO	Mon, Tue, Thu, Fri, Sat: 0800-2000. Wed: 0800-1400.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051/540300	
32	E. LeClerc CONAD	supermarket		44.4978770000000026	11.3933730000000004	Via Larga 10 - Bologna BO	Tue, Wed, Thu, Fri: 0830-2130. Mon: 1200-2100. Sat: 0830-2100.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051/6003811	
33	Plenty Market	supermarket		44.3536530000000013	11.7136720000000008	Via Emilia, 210 - Imola BO	Mon, Tue, Wed, Thu, Fri, Sat: 0830-2000. Sun: 0930-1330, 1630-1930.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0542 39142	
34	Plenty Market	supermarket		44.4907079999999979	11.3554180000000002	Strada Maggiore, 59 - Bologna BO	Mon, Tue, Wed, Thu, Fri, Sat: 0900-2030. Sun: 1000-1400.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 399790	
35	Plenty Market	supermarket		44.484886000000003	11.3488290000000003	Piazza Porta Castiglione, 14 - Bologna BO	Mon, Tue, Wed, Thu, Sat: 0830-2030. Fri: 1200-2030. Sun: 0930-1400, 1630-1930.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 6449992	
36	Plenty Market	supermarket		44.4916369999999972	11.3480559999999997	Via Farini, 30 - Bologna BO	Mon, Tue, Wed, Thu, Fri, Sat: 0900-2030. Sun: 0930-1400, 1630-1930.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 236113	
37	Plenty Market EXPRESS	supermarket		44.4906470000000027	11.3435640000000006	Via Giuseppe Garibaldi, 1 - Bologna BO	Mon, Tue, Wed, Thu, Fri, Sat: 0900-2030. Sun: 1000-1400.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 331700	
38	Supermercato COOP Barca	supermarket		44.4963079999999991	11.2896999999999998	Via della Barca, 57 - Bologna BO	Tue, Wed, Thu, Fri: 0800-2000. Mon: 1430-2000. Sat: 0800-1930.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 562002	
39	Plenty Market	supermarket		44.4996849999999995	11.3509139999999995	Via Irnerio, 24 - Bologna BO	Mon, Tue, Wed, Thu, Fri, Sat: 0900-2100. Sun: 0930-1400, 1630-1930.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 4210066	
40	Plenty Market	supermarket		44.5019520000000028	11.3393339999999991	Piazza dei Martiri, 5 - Bologna BO	Mon, Tue, Wed, Thu, Fri, Sat: 0830-2030. Sun: 0930-1400, 1630-1930.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 245799	
41	Plenty Market	supermarket		44.4959130000000016	11.3399800000000006	Via Monte Grappa, 11 - Bologna BO	Mon, Tue, Wed, Thu, Fri, Sat: 0830-2030. Sun: 1000-1400.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 7459206	
42	Minimercato COOP Via del Pratello	supermarket		44.4954570000000018	11.3292529999999996	Via del Pratello 98 - Bologna BO	Mon, Tue, Wed, Thu, Fri, Sat: 0800-2000.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 524608	
43	Plenty Market	supermarket		44.4911630000000002	11.3200620000000001	Via 21 Aprile 1945, 8 - Bologna BO	Mon, Tue, Wed, Thu, Fri, Sat: 0900-2100.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 7173654	
44	Plenty Market	supermarket		44.461115999999997	11.4241349999999997	Via S. Calindri, 90 - San Lazzaro di Savena BO	Mon, Tue, Wed, Thu, Fri, Sat: 0800-2000.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 6257433	
45	Plenty Market	supermarket		44.5039579999999972	11.4543759999999999	Via Tosarelli, 109 - Castenaso BO	Mon, Tue, Wed, Thu, Fri, Sat: 0800-2100.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 789143	
46	Minimercato COOP DUC	supermarket		44.5104779999999991	11.3401639999999997	Piazza Liber Paradisus 3 - Bologna BO	Mon, Tue, Wed, Thu, Fri: 0800-1930. Sat: 0800-1400.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0	
47	PAM MARCONI	supermarket		44.4988930000000025	11.3386600000000008	Via Guglielmo Marconi, 28 - Bologna BO	Mon, Tue, Wed, Thu, Fri, Sat: 0730-2030. Sun: 0900-1900.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051/520404	
48	Minimercato COOP Gallia	supermarket		44.4692859999999968	11.3830670000000005	via Savigno 3 - Bologna BO	Mon, Tue, Wed, Fri, Sat: 0800-2000. Thu: 0800-1330.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 444003	
49	Minimercato COOP Due Torri	supermarket		44.4945930000000018	11.3475809999999999	via San Vitale 4 - Bologna BO	Mon, Tue, Wed, Thu, Fri, Sat: 0800-2030. Sun: 0900-1330.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 232243	
50	CONAD	supermarket		44.4873580000000004	11.3777939999999997	Viale Felsina 31 - Bologna BO	Mon, Tue, Wed, Fri, Sat: 0745-1930. Thu: 0745-1300.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051/543773	
51	CONAD	supermarket		44.5015920000000023	11.3500689999999995	Via Angelo Finelli 8 - Bologna BO	Mon, Tue, Wed, Thu, Fri, Sat: 0815-1945.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051/241518	
52	CONAD	supermarket		44.4997469999999993	11.3279040000000002	Viale Antonio Silvani 3/7 - Bologna BO	Mon, Tue, Wed, Thu, Fri, Sat: 0815-2000.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051/6494577	
53	CONAD	supermarket		44.5116849999999999	11.3897480000000009	Via Luigi Pirandello 18 - Bologna BO	Mon, Tue, Wed, Thu, Fri, Sat: 0730-1930.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051/501127	
54	Natura Sì Bologna	supermarket		44.5184240000000031	11.394425	Viale Della Repubblica, 23/Ii - Zona Fiera - 40127 Bologna	Tue, Wed, Thu, Sat: 0900-1930. Mon: 1400-2000. Fri: 0900-2000.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051/503902	
55	CONAD	supermarket		44.4771629999999973	11.3841210000000004	Via Lombardia 17/2 - Bologna BO	Mon, Tue, Wed, Thu, Fri, Sat: 0800-1930.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051/541207	
56	Natura Sì Casalecchio Di Reno	supermarket		44.4723820000000032	11.637416	Via Porrettana, 388 Rotonda Biagi 40033 Casalecchio di Reno	Tue, Wed, Thu, Sat: 0900-1930. Mon: 1400-2000. Fri: 0900-2000.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 0494944	
57	CONAD	supermarket		44.4817910000000012	11.3903350000000003	Viale Abramo Lincoln 5 - Bologna BO	Mon, Tue, Wed, Fri, Sat: 0800-2000. Thu: 0800-1300.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051/541052	
58	CONAD	supermarket		44.5035900000000026	11.2774420000000006	Via De Nicola 1 - Bologna BO	Mon, Tue, Wed, Thu, Fri, Sat: 0800-1930.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051/561200	
59	CONAD	supermarket		44.4943799999999996	11.3301859999999994	Via Sant'Isaia 67-2 - Bologna BO	Mon, Tue, Wed, Thu, Fri, Sat: 0815-2000.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051/6492194	
60	Ipermercato COOP Centro Lame	supermarket		44.5143699999999995	11.3309230000000003	Via Beverara, 50 - Bologna BO	Tue, Wed, Thu, Fri: 0830-2130. Mon: 1200-2130. Sat: 0830-2100.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 6359111	
61	PAM BELLARIA	supermarket		44.4760040000000032	11.3870360000000002	Via Bellaria, 47 - Bologna BO	Mon, Tue, Wed, Fri, Sat: 0800-2100. Thu: 0800-1300.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051/544759	
62	Natura Sì San Giovanni In Persiceto	supermarket		44.6335600000000028	11.1911140000000007	Via Bologna, 15/B 400San-17 Giovanni In Persiceto	Tue, Wed, Thu, Fri, Sat: 0900-1300, 1600-2000. Mon: 1600-2000.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 825832	
63	Ipermercato COOP Centro Nova	supermarket		44.4919659999999979	11.4254460000000009	Via Villanova, 29 - Castenaso BO	Tue, Wed, Thu, Fri: 0830-2130. Mon: 1200-2130. Sat: 0830-2100.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 5067011	
64	Minimercato COOP Via dei Lamponi	supermarket		44.4743569999999977	11.3699359999999992	via dei Lamponi 5 - Bologna BO	Mon, Tue, Wed, Fri, Sat: 0830-2000. Thu: 0800-1330.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 6231118	
65	Minimercato COOP Via Ugo Bassi	supermarket		44.4960239999999985	11.3389740000000003	Via Nazario Sauro 4 - Bologna BO	Mon, Tue, Wed, Thu, Fri, Sat: 0800-2030. Sun: 0930-1330.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 6486245	
66	Minimercato COOP Via Mengoli	supermarket		44.4903819999999968	11.3721200000000007	via Mengoli 34 - Bologna BO	Mon, Tue, Wed, Fri, Sat: 0800-2000. Thu: 0800-1330.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 6360493	
67	Supermercato COOP Andrea Costa	supermarket		44.4938059999999993	11.311814	via Andrea Costa, 160 - Bologna BO	Tue, Wed, Thu, Fri: 0800-2030. Mon: 1400-2000. Sat: 0800-2000.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 6154939	
68	PAM CORTICELLA	supermarket		44.5524580000000014	11.3467629999999993	Via Di Corticella, 3 - Bologna BO	Mon, Tue, Wed, Fri, Sat: 0800-2100. Thu: 0800-1300.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051/356403	
69	Plenty Market	supermarket		0	0	Via San Vitale, 22/B - Budrio BO	Mon, Tue, Wed, Thu, Fri, Sat: 0830-1930.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 800986	
70	Plenty Market	supermarket		44.6889299999999992	11.3972709999999999	Via Galliera Sud, 87/89 - San Pietro in Casale BO	Mon, Tue, Wed, Thu, Fri, Sat: 0830-2000.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 818010	
71	Supermercato COOP Viale della Repubblica	supermarket		44.5061559999999972	11.3600720000000006	via Casciarolo 3 - Bologna BO	Tue, Wed, Thu, Fri: 0800-2030. Mon: 1200-2000. Sat: 0800-2000.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 502187	
72	Ipermercato COOP Centro Borgo	supermarket		44.5206179999999989	11.2660710000000002	Via Marco Emilio Lepido, 184 - Bologna BO	Tue, Wed, Thu, Fri: 0830-2130. Mon: 1200-2130. Sat: 0830-2100.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 4131011	
73	Plenty Market EXPRESS	supermarket		44.4968629999999976	11.3459319999999995	Via Guglielmo Oberdan, 24 - Bologna BO	Mon, Tue, Wed, Thu, Fri, Sat: 0900-2100. Sun: 1000-1400.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 239753	
74	Plenty Market EXPRESS	supermarket		44.494056999999998	11.3574210000000004	Via Massarenti, 2 - Bologna BO	Mon, Tue, Wed, Thu, Fri, Sat: 0900-2100.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 341826	
75	Plenty Market EXPRESS	supermarket		44.5004769999999965	11.3340479999999992	Via Calori, 1 - Bologna BO	Mon, Tue, Wed, Thu, Fri, Sat: 0900-2030. Sun: 0930-1330, 1630-1930.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 6494036	
76	Plenty Market EXPRESS	supermarket		44.5018639999999976	11.3645440000000004	Via Amaseo, 25 - Bologna BO	Mon, Tue, Wed, Thu, Fri, Sat: 0900-2030.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 7414327	
77	Supermercato COOP Piazza Martiri	supermarket		44.5009280000000018	11.3418770000000002	Via Montebello, 2/3 - Bologna BO	Mon, Tue, Wed, Thu, Fri: 0800-2000. Sat: 0800-1930.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 249469	
78	Supermercato COOP Saffi	supermarket		44.5021580000000014	11.3155059999999992	Via Francesco Baracca, 14 - Bologna BO	Mon, Tue, Thu, Fri: 0800-2000. Wed: 0800-1330. Sat: 0800-1930.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 380064	
79	Supermercato COOP Dagnini	supermarket		44.4803410000000028	11.3700320000000001	Via Dagnini, 32 - Bologna BO	Mon, Tue, Thu, Fri: 0800-2000. Wed: 0800-1300. Sat: 0800-1930.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	516056559	
80	Supermercato COOP Officine Minganti	supermarket		44.5112790000000018	11.3521049999999999	via della Liberazione 11 - Bologna BO	Tue, Wed, Thu, Fri, Sat: 0900-2100. Mon: 1200-2100.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 6313370	
81	Supermercato COOP San Vitale	supermarket		44.492322999999999	11.3641559999999995	Via Massarenti, 102 - Bologna BO	Tue, Wed, Thu, Fri, Sat: 0800-2000. Mon: 1430-2000.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 342723	
82	Supermercato COOP Viale Carnacini	supermarket		44.5135760000000005	11.4020589999999995	viale Carnacini, 37 - Bologna BO	Tue, Wed, Thu, Fri, Sat: 0830-2100. Mon: 1300-2100.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 6335086	
83	Supermercato COOP San Donato	supermarket		44.5057509999999965	11.3724290000000003	Via San Donato, 87 - Bologna BO	Mon, Tue, Thu, Fri: 0800-2000. Wed: 0800-1330. Sat: 0800-1930.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 6334416	
84	Supermercato COOP San Ruffillo	supermarket		44.4661460000000019	11.3735049999999998	via Ponchielli, 23 - Bologna BO	Tue, Wed, Thu, Fri, Sat: 0800-2100. Mon: 1300-2100.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 481474	
85	Co.de.as. S.n.c	supermarket		44.0478629999999995	12.5907490000000006	Via Giaime Pintor, 7 - Rimini RN	Tue, Wed, Thu, Fri, Sat: 0930-2100. Mon: 1400-2100.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 307320	
86	Mare Market Di Grilli Secondino E C.(S.N.C.) - Alimentari	supermarket		44.0575890000000001	12.5917030000000008	Viale Regina Elena, 82 - Rimini RN	Tue, Wed, Thu, Fri, Sat: 0830-1930. Sun: 0900-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 381373 	
87	Alimentari Selva Mirco	supermarket		44.0509619999999984	12.5892579999999992	Via Michelangelo Zanotti, 2 - Rimini RN	Tue, Wed, Thu, Fri, Sat: 0800-2100. Sun: 0900-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 380076	
88	Lombardini Discount S.P.A.	supermarket		44.0435069999999982	12.5735899999999994	Viale della Repubblica, 100 - Rimini RN	Mon, Tue, Thu, Fri, Sat: 0830-2000. Wed: 0800-1330. Sun: 0900-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 309166	
89	Rinaldi - Alimentari Crai	supermarket		44.0589620000000011	12.5548690000000001	Via Dario Campana, 11 - Rimini RN	Mon, Tue, Thu, Fri: 0800-2000. Wed: 0830-1430. Sat: 0830-2030.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 773040	
90	Bizzocchi - Generi Alimentari	supermarket		44.0672899999999998	12.5622509999999998	Via Madonna della Scala, 51 - Rimini RN	Mon, Tue, Fri, Wed, Thu, Sun: 0830-1330. Sat: 0900-1930.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 52464	
91	Buratta - Alimentari Vendita	supermarket		44.0521079999999969	12.5793210000000002	Viale Giovanni Pascoli, 73 - Rimini RN	Tue, Wed, Thu, Fri, Sat: 0900-2100. Sun: 0900-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 387668	
92	Emmedi Srl	supermarket		44.0711500000000029	12.5778610000000004	Viale Antonio Beccadelli, 37 - Rimini RN	Mon, Tue, Thu, Fri: 0800-2000. Wed: 0900-1400. Sat: 0830-2030.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 191 3470	
93	Maccaroni - Alimentari Frutta Verdura	supermarket		44.0142990000000012	12.6421740000000007	Viale Luigi Angeloni, 11 - Riccione Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0800-2100.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 647650	
94	Euromarket Di Angelini Ado e C.(S.N.C.)	supermarket		43.9984949999999984	12.6545330000000007	Viale Torquato Tasso, 110 - Riccione Rimini RN	Mon, Tue, Wed, Thu, Fri: 0800-1430. Sat: 0800-1930. Sun: 0900-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 646514	
95	C.N.C. Di Lombardi Antonio E C. Snc.	supermarket		44.0844549999999984	12.5313829999999999	Via Piave, 16 - Santarcangelo di Romagna, RN	Tue, Wed, Thu, Fri, Sat: 0800-2100. Mon: 1330-2030.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 621666	
96	Eurosisagroup Srl	supermarket		43.9866389999999967	12.570627	Via Montescudo, 14 - Coriano Rimini, RN	Mon, Tue, Wed, Thu, Fri, Sat: 0830-2100.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 659019	
97	Centro Commerciale Condor	supermarket		44.0418080000000032	12.5835030000000003	Via Macanno, 59 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0900-1930.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 386180	
98	Dial S.r.l.	supermarket		44.0693229999999971	12.5670929999999998	Via Lucio Lando, 3 - Rimini RN	Mon, Tue, Wed, Fri, Sat: 0800-2030. Thu: 0900-1330.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 709126	
99	Flaminia Alimentari Snc Di Neri Mauro E Dal Pozzo Davide - Ingrosso Latticini Salumi	supermarket		44.036406999999997	12.5989129999999996	Via Flaminia, 203 - Rimini RN	Tue, Wed, Thu, Fri: 0830-2130. Mon: 1300-2130. Sat: 0930-2000. Sun: 0900-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 384064	
100	Garattoni - Alimentari	supermarket		44.0071390000000022	12.6453399999999991	Via Daniele Felici, 19 - Santarcangelo di Romagna, RN	Tue, Wed, Thu, Fri, Sat: 0830-2100. Sun: 0900-1330.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 626082	
101	E.M.P Snc Di Muratori Dario E C. - Alimentari 	supermarket		44.0693339999999978	12.5670719999999996	Via Dario Campana, 93 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0800-2130. Sun: 0800-1330.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 772140	
102	C.N.C. Di Lombardi Antonio E C. Snc	supermarket		44.0844549999999984	12.5313829999999999	Via Angelo Cenci, 2 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0800-2100. Sun: 0900-1900.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 736531	
103	Pan Biscotto Biodinamico	supermarket		44.0600859999999983	12.5717090000000002	Via Castelfidardo, 13 - Rimini RN	Mon, Tue, Wed, Thu, Sat: 0800-1400. Sun: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 54803	
104	Coop Rimini Celle	supermarket		44.0687909999999974	12.5492989999999995	Via 23 Settembre 1845, 128 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0830-2030. Sun: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 74170	
105	Biagini - Ingrosso Alimentari	supermarket		44.0612059999999985	12.4596040000000006	Via Rughi, 280 - Santarcangelo di Romagna, RN	Mon, Tue, Wed, Thu, Fri, Sat: 0900-1930. Sun: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 621168	
106	Shopping Centre Le Befane	supermarket		44.0361460000000022	12.5803759999999993	Via Circonvallazione Nuova, 85 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0830-2100.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 387995	
107	Super Market Oriental Sas Di Chen Zhaoyun	supermarket		44.0633240000000015	12.5697620000000008	Via Alessandro Gambalunga, 70 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0830-2000.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 20930	
108	R.a.p. Di Renzini Adamo E C. S.n.c	supermarket		44.0595280000000002	12.5722649999999998	Via Carlo Cattaneo, 9 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0900-2100. Sun: 0930-2000.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 55326	
109	Grosrimini - Centro Commerciale Ingrosso Rimini Spa	supermarket		44.0361249999999984	12.5803349999999998	Via Coriano, 58 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0830-2030. Sun: 0830-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 386602	
111	Conad Euromarket - Mercato Coperto	supermarket		44.0595229999999987	12.5722690000000004	Via Castelfidardo, 15 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0830-2100. Sun: 0930-2000.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 53064	
112	Nuovo Conad Tiberio Di Semprini Sandra E C.	supermarket		44.0657720000000026	12.5607900000000008	Viale Tiberio, 32- Rimini RN	Mon, Tue, Wed, Thu, Sat: 0830-2030. Fri: 1230-2030.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 52147	
113	S.g.i. srl	supermarket		44.0441760000000002	12.5820450000000008	Via Macanno, 13 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sun: 1000-1400.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 769611	
114	Centro Commerciale I Malatesta	supermarket		44.0685160000000025	12.5253440000000005	Via Emilia, 150 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0930-2100.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 743310	
115	Supermercato La Fonte Di Bellavista Giuseppe E C. S.N.C.	supermarket		44.0827579999999983	12.5372559999999993	Via Sacramora, 62 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0900-1930. Sun: 0900-1330.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 735547	
116	Soges Srl Supermercato	supermarket		44.0287659999999974	12.6147200000000002	Viale Parigi, 10 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0800-2000.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 478963	
117	Vip Discount (S.R.L.)	supermarket		44.0788480000000007	12.4628350000000001	Viale Italia, 2 - Rimini RN	Tue, Wed, Thu, Fri: 0930-2130. Sat: 0830-2100. Sun: 0930-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 740310	
118	Giua - Alimentari	supermarket		44.0665669999999992	12.5775489999999994	Viale Trieste, 34 - Rimini RN	Mon, Tue, Wed, Thu, Fri: 0930-1930. Sat: 0830-2100. Sun: 0930-1330.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 27348	
119	CONAD Mita	supermarket		44.0530759999999972	12.5446539999999995	Via Padulli, 1 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0830-2000. Sun: 0900-1330.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 778262 	
120	Semprini	supermarket		44.0822440000000029	12.5470109999999995	Viale Paolo Toscanelli, 132 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0800-1930. Sun: 0800-1330.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 732881	
121	Gemi Di Izzo Michele e C. Snc	supermarket		44.0530210000000011	12.5805919999999993	Viale Giovanni Pascoli, 33 - Rimini RN	Mon, Tue, Wed, Fri, Sat: 0745-1930. Sun: 0930-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 385704	
122	Valente - Frutta - Verdura	supermarket		44.0488470000000021	12.5619650000000007	Via Acquario, 66 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0930-2030.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 772563	
123	Santamaria - Alimentari	supermarket		44.0648300000000006	12.5834659999999996	Viale Misurata, 7 - Rimini RN	Mon, Tue, Wed, Fri, Sat: 0800-2100. Sun: 0800-1330.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 391722	
124	Gessaroli - Bar Latteria Alimentari Salumeria	supermarket		44.088479999999997	12.5329040000000003	Via Eugenio Curiel, 36 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0900-2000.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 734794	
125	Ermeti - Alimentari	supermarket		44.049075000000002	12.596368	Via Giuseppe Regaldi - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sun: 0830-1230. Sat: 0830-2000.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 380464	
126	Rimini Market Di Sfera Vincenzo  C. S.N.C.	supermarket		44.044750999999998	12.5815359999999998	Via Primo Maggio, 1 - Rimini RN	Tue, Wed, Thu, Fri: 0830-2000. Mon: 1230-1900. Sat: 0830-1930.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 380800	
127	Morri Francesco E Alessandro Generi Alimentari Snc - Alimentari	supermarket		44.0201100000000025	12.4532039999999995	Via Marecchiese, 564 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0800-2030. Sun: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 750126	
128	Eurosisagroup S.R.L. Supermercato	supermarket		44.0494109999999992	12.5562249999999995	Via Covignano, 117/a - Rimini RN	Mon, Tue, Wed, Fri, Sat: 0830-2000. Sun: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 773190	
129	Arca Spa - Super Aro	supermarket		43.9985319999999973	12.6544810000000005	Viale Maria Ceccarini, 156 -Riccione Rimini RN 	Mon, Tue, Wed, Thu, Fri: 0830-1930. Sat: 0830-2100.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 606426	
130	A.p.e. S.n.c.	supermarket		44.0444659999999999	12.5669039999999992	Via Euterpe, 3 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0900-2000. Sun: 0830-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 772041	
131	Conad Rio Agina Di Ottaviani Giuseppececchini Giorgio E C Snc	supermarket		43.9989020000000011	12.6301819999999996	Viale Veneto, 43 - Riccione Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0830-2000.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 660571	
132	Iper Rimini	supermarket		44.0685199999999995	12.5303930000000001	Via Emilia, 130 - Rimini RN	Mon, Tue, Wed, Fri, Sat: 0830-2100.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 359111	
133	Euromarket G.E.A. - Gruppo Esercenti Associati Di Zannoni Stefano C.	supermarket		44.0530970000000011	12.5721720000000001	Via della Fiera, 2 - Rimini RN	Mon, Tue, Wed, Fri, Sat: 0800-2100. Sun: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 788391	
134	Superstore Conad La Fonte	supermarket		44.0822509999999994	12.5384469999999997	Viserba - Viserba RN	Mon, Tue, Wed, Thu, Fri, Sat: 0830-2000. Sun: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 732238	
135	Coin	supermarket		44.059114000000001	12.5676900000000007	Corso d'Augusto, 59 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0900-2000.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 28954	
136	Amarcord S.R.L.	supermarket		44.0676360000000003	12.5808090000000004	Viale Amerigo Vespucci, 67 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0900-2030. Sun: 0800-1900.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 56956	
137	Incoop Miramare	supermarket		44.0822829999999968	12.5384899999999995	Viale Guglielmo Marconi, 45 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0830-2100. Sun: 0930-1930.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 373141	
139	Rimini Centro Di Bucci Loris E Pancotti Iuri Snc	supermarket		44.0676380000000023	12.5808049999999998	Via Alessandro Serpieri, 12 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0900-2100. Sun: 0800-1900.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 56833	
140	Dulca S.r.l	supermarket		44.0361249999999984	12.5803349999999998	Via Coriano, 58 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0900-2030. Sun: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 396238	
141	Sviluppo Discount (S.P.A.)	supermarket		44.0380800000000008	12.5924139999999998	Via 23 Settembre 1845, 85 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0900-2030. Sun: 0930-1930.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 741709	
142	Croce Bianca	farmacia		44.5007889999999975	11.3233599999999992	Via Saffi 63, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 558053	
143	Cooperativa	farmacia		44.5139950000000013	11.3275819999999996	Via Marco Polo 3, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 6341275	
144	Comunale Murri	farmacia		44.4774439999999984	11.3660879999999995	Via Murri 131/f, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 6235757	
145	Comunale Marzabotto	farmacia		44.5209890000000001	11.3446709999999999	Via Marzabotto 14, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 6140020	
146	Comunale Repubblica	farmacia		44.5071859999999973	11.3601360000000007	Via Cleto Tomba 29, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 6332903	
147	Comunale Piazzamaggiore	farmacia		44.4939529999999976	11.3424289999999992	Piazza Maggiore 6, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri, Sat, Sun: 0000-2400. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:0000-2400.	051 239690	
148	Comunale Stendhal	farmacia		44.5323350000000033	11.3542229999999993	Via Stendhal 5/a, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 322235	
149	Comunale S. Donato	farmacia		44.513773999999998	11.3882180000000002	Via S. Donato 99, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 503058	
150	Comunale Triumvirato	farmacia		44.5190410000000014	11.2938229999999997	Via Triumvirato 28, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 382447	
151	Comunale Toscana	farmacia		44.4665129999999991	11.3709120000000006	Via Toscana 38/p, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 474488	
152	Comunale Don Sturzo	farmacia		44.4890740000000022	11.2981630000000006	Via Don Sturzo 31, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 432289	
153	Comunale Emilia Ponente	farmacia		44.5113429999999966	11.2893349999999995	Via Emilia Ponente 258/b, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 569724	
154	Comunale Crocioni	farmacia		44.4925479999999993	11.3011759999999999	Via Crocioni 1/a, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 435958	
155	Comunale De Nicola	farmacia		44.5035900000000026	11.2774420000000006	Via De Nicola 1, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 561509	
156	Comunale Cavazzoni	farmacia		44.4699499999999972	11.3820379999999997	Via Cavazzoni 2, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 440639	
157	Comunale Costa	farmacia		44.4944130000000015	11.3130679999999995	Via A. Costa 156, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 6142482	
158	Comunale Battaglia	farmacia		44.4652249999999967	11.3773199999999992	Via Della Battaglia 25/e, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 474518	
159	Comunale Battindarno	farmacia		44.5058700000000016	11.3020180000000003	Via Battindarno 28, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 382646	
160	Comunale Felsina	farmacia		44.4875339999999966	11.3777980000000003	Viale Felsina 35, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 544065	
161	Comunale Ferrarese	farmacia		44.5166409999999999	11.3546829999999996	Via Ferrarese 153/b, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 365887	
162	S. Maria Delle Grazie	farmacia		44.4757650000000027	11.3777620000000006	Via Degli Orti 68/d-e, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 547180	
163	S. Mamolo	farmacia		44.4854709999999969	11.3393440000000005	Via S. Mamolo 25/b, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 580080	
164	S. Paolo	farmacia		44.4913730000000029	11.339753	Via Collegio Di Spagna 1/a, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 235428	
165	S. Martino	farmacia		44.5227810000000019	11.3196279999999998	Via F. Zanardi 184/a, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 6345686	
166	S. Isaia	farmacia		44.4931210000000021	11.3357189999999992	Via S. Isaia 2/a, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 333285	
167	S. Giuseppe	farmacia		44.4903630000000021	11.3252659999999992	Via Saragozza 105, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 6446394	
168	S. Lucia	farmacia		44.4995940000000019	11.2954260000000009	Via Battindarno 139/c, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 569056	
169	S. Lorenzo	farmacia		44.495708999999998	11.3378619999999994	Via Ugo Bassi 25, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 238275	
170	S. Ruffillo	farmacia		44.4628500000000031	11.37059	Via Toscana 58, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 471878	
171	S. Rita	farmacia		44.493350999999997	11.3834140000000001	Via Massarenti 179, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 531203	
172	Del Villaggio Panigale	farmacia		44.5229429999999979	11.2640100000000007	Via Normandia 14, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 400290	
173	Del Sole	farmacia		44.5116849999999999	11.3897480000000009	Via Pirandello 22/a, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 505308	
174	Del Reno	farmacia		44.5086730000000017	11.2971789999999999	Via E. Ponente 156, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 381470	
175	Del Pilastro	farmacia		44.5101650000000006	11.3959430000000008	Via Deledda 26, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 510204	
176	Della Provvidenza	farmacia		44.4935150000000021	11.3745759999999994	Via Massarenti 254, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 345672	
177	Della Cirenaica	farmacia		44.4971209999999999	11.3643230000000006	Via Bentivogli 99/c, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 340902	
178	Della Barca	farmacia		44.4957419999999999	11.2930679999999999	P. Zabonazzi 9/b, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 6196396	
179	Dell'immacolata	farmacia		44.4916869999999989	11.3158049999999992	Via Bastia 18, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 6142050	
180	Della Stazione Centrale	farmacia		44.5054009999999991	11.3424230000000001	Viale Pietramellara 22/a-b, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri, Sat: 0730-2300. Sun: 0800-2200. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:0800-2200.	051 246603	
181	Della Scala	farmacia		44.5173509999999979	11.2757970000000007	Via M.e. Lepido 45/b, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 400191	
182	S. Viola	farmacia		44.5084760000000017	11.2946399999999993	Via Emilia Ponente 72/2, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 381421	
183	Sacchetti	farmacia		44.4899449999999987	11.3411120000000007	Via M. D'azeglio 50, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 330462	
184	S. Salvatore	farmacia		44.4943069999999992	11.3368909999999996	Via Portanova 2, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 232434	
185	S. Silverio Della Chiesa Nuova	farmacia		44.4917140000000018	11.3490160000000007	Via A. Murri 185/b, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 443131	
186	Speranza	farmacia		44.4952850000000026	11.3400400000000001	Via Ugo Bassi 6/h, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 232436	
187	Ss. Annunziata	farmacia		44.493895000000002	11.3451769999999996	Via Orefici 17, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 239014	
188	Siepelunga	farmacia		44.4773210000000034	11.3606060000000006	Via Borghimamo 6/b-c, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 6237160	
189	Spartaco	farmacia		44.4927020000000013	11.3786129999999996	Via Del Parco 40575, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 533356	
190	Ss. Trinità	farmacia		44.4876220000000018	11.3527059999999995	Via S. Stefano 82, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 234521	
191	Tavernari	farmacia		44.487324000000001	11.3396170000000005	Via M. D'azeglio 88, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 583104	
192	Da Porta Saragozza	farmacia		44.4904239999999973	11.3310569999999995	Via Saragozza 71, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 585209	
193	Dal Contavalli	farmacia		44.4973159999999979	11.3475640000000002	Via Mentana 5, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 235825	
194	Dalle Due Torri	farmacia		44.4944800000000029	11.3469940000000005	Via S. Vitale 2/d, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 229452	
195	De Pisis	farmacia		44.5036520000000024	11.2944659999999999	Via Ruffini 2/c, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 6190091	
196	Degli Alemanni	farmacia		44.4842009999999988	11.3727730000000005	Via Mazzini 9/a-b, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 393114	
197	Dei Pini	farmacia		44.495474999999999	11.4003730000000001	Via Barelli 4/d, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 530016	
198	Del Borgo	farmacia		44.5186419999999998	11.2720559999999992	Via M.e. Lepido 147, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 400135	
199	Del Corso	farmacia		44.4902749999999969	11.3500630000000005	Via S. Stefano 38, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 234522	
200	Del Pavaglione	farmacia		44.4931800000000024	11.3436509999999995	Via Archiginnasio 2/a, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 221640	
201	Del Pianeta	farmacia		44.5015619999999998	11.3962599999999998	Galleria Via Larga 33, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 530182	
202	Nuova Del Meloncello	farmacia		44.4900019999999969	11.3114679999999996	Via Saragozza 254/a-d, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 6142332	
203	Moratello	farmacia		44.4784719999999965	11.3686500000000006	Via G. Dagnini 16/b-c, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 6231966	
204	Madonna Della Guardia	farmacia		44.495435999999998	11.3194520000000001	Via A. Costa 107, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 6142141	
205	Lodi	farmacia		44.4951599999999985	11.3246540000000007	Via A. Costa 47/a, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 6143978	
206	Mazzini	farmacia		44.4877430000000018	11.3637770000000007	Via Mazzini 95, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 348997	
207	Marco Polo	farmacia		44.5187960000000018	11.3287460000000006	Via Marco Polo 22/a, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 6345468	
208	Internazionale	farmacia		44.4979020000000034	11.3435799999999993	Via Indipendenza 29, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 235647	
209	Guandalini	farmacia		44.5117880000000028	11.3491079999999993	Via Ferrarese 12/a, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 357657	
210	Lavino Di Mezzo	farmacia		44.5324910000000003	11.2318820000000006	Via M.e. Lepido 222/2, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 401393	
211	Irnerio	farmacia		44.4998480000000001	11.3502609999999997	Via Irnerio 20, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 241517	
212	Fossolo 2 Centro Commerciale	farmacia		44.4817910000000012	11.3903350000000003	Viale Lincoln 5, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 545774	
213	Grimaldi	farmacia		44.5319220000000016	11.3534439999999996	Via Di Corticella 184/3, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 322259	
214	Di Corticella	farmacia		44.5466679999999968	11.3565799999999992	Via Bentini 37, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 705478	
215	Di Porta S. Vitale	farmacia		44.4940560000000005	11.3564579999999999	Via S. Vitale 126, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 231024	
216	Dello Sterlino	farmacia		44.4829519999999974	11.3589760000000002	Via A. Murri 16, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 397324	
217	Di Casaralta	farmacia		44.5165369999999996	11.3546139999999998	Via Ferrarese 66/d-e-f, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 361919	
218	Emilia	farmacia		44.4800299999999993	11.3838279999999994	Via E. Levante 146, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 548005	
219	Ferrari	farmacia		44.4804529999999971	11.3701939999999997	Via Dagnini 34/a-b, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 6230100	
220	Due Madonne	farmacia		44.4755970000000005	11.3963979999999996	Via Tacconi 2/b, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 460332	
221	Duse	farmacia		44.5024939999999987	11.370393	Via E. Duse 20, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 511058	
222	Comunale Barbieri	farmacia		44.5175619999999981	11.3390280000000008	Via F. Barbieri 121, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 355863	
223	Comunale Azzurra	farmacia		44.4875370000000032	11.3735409999999995	Via Azzurra 52/2, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 300417	
224	Comunale Arno	farmacia		44.4728119999999976	11.3874739999999992	Via Arno 36/a, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 461370	
225	Chillemi	farmacia		44.4759219999999971	11.3874449999999996	Via Bellaria 36/d-e, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 544397	
226	Castiglione	farmacia		44.4873509999999968	11.3480720000000002	Via Castiglione 53, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 260202	
227	Carracci	farmacia		44.5086680000000001	11.3426200000000001	Via Tiarini 16, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 357620	
228	Busacchi	farmacia		44.5044329999999988	11.3126139999999999	Via Emilia Ponente 24, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 310826	
229	Bettini	farmacia		44.515543000000001	11.347645	Via Di Corticella 68, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 356333	
230	Bertelli Alla Funivia	farmacia		44.4914289999999966	11.3053460000000001	Via Porrettana 95/f-g, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 6142205	
231	Beata Vergine Di S. Luca	farmacia		44.492564999999999	11.3419899999999991	Via M. D'azeglio 15, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 231138	
232	S. Egidio	farmacia		44.5613529999999969	11.2721809999999998	Via Dell'Artigiano 26/a, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 516180	
233	S. Donnino	farmacia		44.5083070000000021	11.3774669999999993	Via S. Donato 158, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 510025	
234	S. Domenico	farmacia		44.4906470000000027	11.3435640000000006	Via Garibaldi 1, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 330363	
235	S. Caterina	farmacia		44.5305320000000009	11.3522079999999992	Via Di Corticella 180, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 358138	
236	S. Carlo	farmacia		44.5016310000000033	11.3431879999999996	Via Dei Mille 7/2b-c, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 246417	
237	S. Benedetto	farmacia		44.500078000000002	11.3440139999999996	Via Indipendenza 54, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 248384	
238	S. Antonio	farmacia		44.4923130000000029	11.3652139999999999	Via Massarenti 108, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 341912	
239	S. Anna	farmacia		44.5023949999999999	11.3390959999999996	Via Don Minzoni 1/6, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 252452	
240	S. Giorgio	farmacia		44.5056760000000011	11.3658769999999993	Via Garavaglia 6/b, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 503783	
241	S. Ester	farmacia		44.5433189999999968	11.3561750000000004	Via Bentini 11, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 320403	
242	Antica Farmacia Delle Moline	farmacia		44.499054000000001	11.3445070000000001	Via A. Righi 6/a, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 224885	
243	Bartolotti	farmacia		44.5133220000000023	11.3415160000000004	Via Fioravanti 26, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 357511	
244	Al Sacrocuore	farmacia		44.5083819999999974	11.3465589999999992	Via Matteotti 29, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 356945	
245	Al Velodromo	farmacia		44.4985369999999989	11.3197650000000003	Via V. Veneto 19, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 6153933	
246	Alberani	farmacia		44.491461000000001	11.3466349999999991	Via Farini 19, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 224573	
247	Antica Farmacia Dei Servi	farmacia		44.4922439999999995	11.3512350000000009	Strada Maggiore 39, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 231638	
248	Ai Colli	farmacia		44.4852180000000033	11.3483230000000006	Piazza di Porta Castiglione 15/e, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 333300	
249	Aicardi	farmacia		44.4942050000000009	11.3523219999999991	Via San Vitale 58, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 231350	
250	Al Palazzo Dello Sport	farmacia		44.4987220000000008	11.3354149999999994	Via Lame 52, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 522215	
251	Paulin	farmacia		44.4986379999999997	11.3383040000000008	Via Marconi 26, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 232417	
252	Pontevecchio	farmacia		44.4824309999999983	11.3771120000000003	Via Emilia Levante 29, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 490755	
253	Porta Lame	farmacia		44.5038860000000014	11.3322099999999999	Via F. Zanardi 8, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 520720	
254	Porta Mascarella	farmacia		44.5019059999999982	11.3530200000000008	P.za Porta Mascarella 7/a-d, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 244512	
255	Nuova S. Pietro	farmacia		44.4930090000000007	11.3897259999999996	Via Massarenti 223/5, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 531730	
256	Nuova S. Ruffillo	farmacia		44.4567180000000022	11.3692229999999999	Via Toscana 121/2, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 474100	
257	Oberdan	farmacia		44.4952299999999994	11.3453289999999996	Via Altabella 14, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 233339	
258	Parco Nord	farmacia		44.5287629999999979	11.3663380000000007	Via Ferrarese 160, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 321229	
259	Zarri	farmacia		44.4951349999999977	11.3417580000000005	Via Ugo Bassi 1, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 223739	
260	Vittoria	farmacia		44.5008479999999977	11.3736770000000007	Via Andreini 32/m, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 503744	
261	Trento Trieste	farmacia		44.487724	11.3623250000000002	Piazza Trento Trieste 1/a, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 345859	
262	Toschi	farmacia		44.4977919999999969	11.3317309999999996	Via S. Felice 89, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 555062	
263	Regina	farmacia		44.4969419999999971	11.3394349999999999	Via Nazario Sauro 11, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 223800	
264	S. Andrea Alla Barca	farmacia		44.4969150000000013	11.2860980000000009	Via Tommaseo 4/a, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 567119	
265	Zincone	farmacia		44.4765269999999973	11.3832529999999998	Via Sardegna 1, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1230, 1530-1930. 	 01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051 491008	
266	Zamboni	scuolamaterna		44.4959520000000026	11.3499759999999998	via  Zamboni, 15, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
267	Betti Pl. 2	scuolamaterna		44.5011480000000006	11.3447080000000007	via  Irnerio, 2, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
268	Testi Rasponi	scuolamaterna		44.4751609999999999	11.3676069999999996	via  Murri, 159, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
269	Padiglione	scuolamaterna		44.4887879999999996	11.3410829999999994	via  Tovaglie, 4, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
270	Marconi	scuolamaterna		44.4829700000000017	11.3680869999999992	via  L. Bassi, 20-22, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
271	Tambroni	scuolamaterna		44.4739819999999995	11.3685270000000003	via  Murri, 158, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
272	Arcobaleno	scuolamaterna		44.4879669999999976	11.374803	via  Arcobaleno, 17, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
273	Frank Anna	scuolamaterna		44.4925920000000019	11.3779900000000005	via  Spartaco, 1, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
274	Marighetto	scuolamaterna		44.4879669999999976	11.374803	via  Arcobaleno, 17, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
275	XVIII Aprile	scuolamaterna		44.4964039999999983	11.3804370000000006	via  Scandellara, 9/4, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
276	Degli Esposti	scuolamaterna		44.4822210000000027	11.3560300000000005	P.le Jacchia, 1, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
277	Cattaneo	scuolamaterna		44.4792920000000009	11.3722809999999992	Largo Lercaro, 10, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
278	Gastone Rossi	scuolamaterna		44.480279000000003	11.373761	via  Nadi, 23, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
279	Gabelli	scuolamaterna		44.4813589999999976	11.3383800000000008	via  Bellombra, 28/3, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
280	Baraccano	scuolamaterna		44.4862719999999996	11.350441	via  Pascoli, 3, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
281	Bacchi	scuolamaterna		44.4813589999999976	11.3383800000000008	via  Bellombra, 28/3, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
282	Carducci	scuolamaterna		44.4870149999999995	11.3544870000000007	via  Dante, 3, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
283	Beltrame	scuolamaterna		44.4810050000000032	11.3457709999999992	via  Putti, 32, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
284	Molino Tamburi	scuolamaterna		44.4822160000000011	11.3560580000000009	P.le Jacchia, 2, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
285	Il Monello	scuolamaterna		44.4814790000000002	11.3731480000000005	via  Pellizza da Volpedo, 11, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
286	Rocca	scuolamaterna		44.5040899999999979	11.3563139999999994	via  Gandusio 4, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
287	Tobagi	scuolamaterna		44.5078140000000033	11.3776209999999995	viale Zagabria, 1, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
288	Iole Baroncini	scuolamaterna		44.5045130000000029	11.3750129999999992	via  Benini, 1, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
289	Negri Ada	scuolamaterna		44.5128789999999981	11.3976279999999992	via  Campana, 53, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
290	Gualandi	scuolamaterna		44.5023169999999979	11.365456	via  dell?Artigiano, 5, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
291	Panzini	scuolamaterna		44.5086659999999981	11.3939609999999991	via  Panzini, 5, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
292	Benini	scuolamaterna		44.5035740000000004	11.3747109999999996	via  Benini, 3, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
293	Gualandi - Palazzina	scuolamaterna		44.5029749999999993	11.3659320000000008	via  Beroaldo, 2, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
294	Garibaldi	scuolamaterna		44.5002210000000034	11.3733550000000001	via  Andreini, 41, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
295	Gualandi - Gioannetti	scuolamaterna		44.5051699999999997	11.3652580000000007	via  Gioannetti, 2, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
296	Presi	scuolamaterna		44.4969090000000023	11.2882990000000003	via  Tolstoi, 1, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
297	Pedrielli	scuolamaterna		44.5109130000000022	11.3032240000000002	via  del Giacinto, 35, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
298	Morandi	scuolamaterna		44.4933320000000023	11.2923010000000001	via  Beccaccino, 27, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
299	Fantini	scuolamaterna		44.4915639999999968	11.2919809999999998	via  Lorenzetti, 8, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
300	Don Milani	scuolamaterna		44.4986800000000002	11.2926059999999993	via  Gucci, 14, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
301	Albertazzi	scuolamaterna		44.5041409999999971	11.3070199999999996	via  Berretta Rossa, 15, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
302	De Amicis	scuolamaterna		44.5033639999999977	11.341215	via  Milazzo, 3/1, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
303	Marzabotto	scuolamaterna		44.5028829999999971	11.3115129999999997	via  Monterumici, 1/4, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
304	Giovanni XXIII	scuolamaterna		44.4979950000000031	11.2852219999999992	via  Verga, 4, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
305	Seragnoli	scuolamaterna		44.508344000000001	11.2976790000000005	via  Speranza, 32, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-2, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
306	Nuova Scuola Infanzia Navile	scuolamaterna		44.4941900000000032	11.3465190000000007	via  C. da Bologna BO, 29, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
307	Andersen	scuolamaterna		44.5010260000000031	11.3277319999999992	via  dello Scalo, 17/2, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
308	Dall'olio	scuolamaterna		44.5028829999999971	11.3115129999999997	via  Monterumici, 1/2, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
309	Dozza Giuseppe	scuolamaterna		44.5028829999999971	11.3115129999999997	via  Monterumici, 1, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
310	Dozza	scuolamaterna		44.5297240000000016	11.3652379999999997	via  della Dozza, 8, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
311	Coop Azzurra Statale	scuolamaterna		44.5222639999999998	11.3313059999999997	via  della Beverara, 188, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
312	Succ. Dozza "il Flauto Magico"	scuolamaterna		44.516292	11.3513099999999998	via  Lombardi, 40, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
313	Girotondo	scuolamaterna		44.5425589999999971	11.3564170000000004	via  Pettazzoni, 1, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
314	Guidi Teresina	scuolamaterna		44.5004589999999993	11.3310479999999991	via  Calori, 8, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
315	Mago Merlino	scuolamaterna		44.5020150000000001	11.334835	via  Azzogardino, 63, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
316	Scarlatti	scuolamaterna		44.4680760000000035	11.3723469999999995	via  Scarlatti, 1, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
317	S. Domenico Savio	scuolamaterna		44.4778829999999985	11.3964029999999994	via  Golinelli, 2, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
318	Don Marella	scuolamaterna		44.4886750000000006	11.3842130000000008	via  Populonia, 9, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
319	Deledda	scuolamaterna		44.4734740000000031	11.3872859999999996	via  Domodossola, 2, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
320	Bertolini (ex Costa)	scuolamaterna		44.4717640000000003	11.3799069999999993	via  Milano, 13, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
321	Ferrari Statale	scuolamaterna		44.4595249999999993	11.3696789999999996	via Buon Pastore, 2/2, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
322	Viscardi	scuolamaterna		44.4816470000000024	11.3826630000000009	via  Bartolini, 4, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
323	Sanzio	scuolamaterna		44.4650189999999981	11.3788280000000004	via  Abba, 5, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
324	Coop Azzurra Comunale	scuolamaterna		44.5222639999999998	11.3313059999999997	via  della Beverara, 188, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
325	Ceccarelli	scuolamaterna		44.5125930000000025	11.349145	via  Saliceto, 8/2, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
326	Federzoni	scuolamaterna		44.5080699999999965	11.3442659999999993	via  di Vincenzo, 11, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
327	Del Mugnaio	scuolamaterna		44.5256919999999994	11.3498920000000005	via  Corticella, 147/2, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
328	Lanzarini	scuolamaterna		44.531680999999999	11.3512789999999999	via  Marziale, 10, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
329	Grosso	scuolamaterna		44.5264379999999989	11.3418960000000002	via  Erbosa, 20-22, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
330	Marsili	scuolamaterna		44.5443440000000024	11.3571950000000008	via  Colombarola, 38/6, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
331	Manzini	scuolamaterna		44.5186190000000011	11.326924	Piazza Giovanni da Verazzano, 1, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
332	Zucchelli	scuolamaterna		44.5239109999999982	11.3220759999999991	via  Ca' Bianca, 13 /2, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
333	Neri Attilia	scuolamaterna		44.5443440000000024	11.3571950000000008	via  Colombarola, 38/6, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
334	Ferrari Nuova	scuolamaterna		44.4595249999999993	11.3696789999999996	via  Buon Pastore, 2/2, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
335	Follerau	scuolamaterna		44.4856639999999999	11.377008	viale Felsina, 25, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
336	Ciari Bruno	scuolamaterna		44.4765099999999975	11.3801120000000004	L.go Brescia, 10, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
337	Walt Disney	scuolamaterna		44.4684529999999967	11.3838439999999999	via  Bezzecca, 8, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
338	XXI Aprile	scuolamaterna		44.491579999999999	11.3145050000000005	via  Onofri, 7, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
339	Manzolini	scuolamaterna		44.4936069999999972	11.3337579999999996	via  S. Isaia, 20, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
340	Arco Guidi Costa	scuolamaterna		44.4938059999999993	11.311814	via Andrea Costa 162, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
341	Serra Anna Pl. 1 e Pl. 2	scuolamaterna		44.4929599999999965	11.3330660000000005	via  Ca' Selvatica, 11/3, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
342	Gli Amici Di Giovanni	scuolamaterna		44.4687169999999981	11.3898130000000002	via  Bassano del Grappa, 4, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
343	Mazzoni	scuolamaterna		44.4728720000000024	11.3812610000000003	via  Milano, 11, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
344	Flora (ex Acri)	scuolamaterna		44.5160669999999996	11.3382419999999993	via  Flora, 7, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
345	Bolzani	scuolamaterna		44.5160669999999996	11.3382419999999993	via  Flora, 3, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
346	Villa May	scuolamaterna		44.5202540000000013	11.2747759999999992	via  Bufalini, 16, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
347	Via Bragaglia	scuolamaterna		44.4941900000000032	11.3465190000000007	via  Bragaglia, 28, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
348	Aldo Moro	scuolamaterna		44.5193870000000018	11.293412	via  Calvi, 3/3, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
349	Gida Rossi	scuolamaterna		44.500466000000003	11.2776530000000008	via  Caduti di Casteldebole, 19, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
350	Gallon	scuolamaterna		44.5197670000000016	11.2686379999999993	via  M. E. Lepido, 175, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
351	Mazzini Infanzia	scuolamaterna		44.5229309999999998	11.2674160000000008	via  Legnano, 2, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
352	Casa Del Bosco	scuolamaterna		44.5097710000000006	11.2851839999999992	via  della Pietra, 21/2, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
353	Arco Guidi Pace	scuolamaterna		44.492998	11.3114659999999994	Piazza della Pace, 3 /3, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
354	Gobetti	scuolamaterna		44.4913310000000024	11.3226080000000007	via  Perti, 26, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
355	Villetta Mattei	scuolamaterna		44.4948290000000028	11.4002400000000002	via  Mattei, 20, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
356	Giordani	scuolamaterna		44.4962289999999996	11.366244	via  Sante Vincenzi, 43, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
357	Don Bosco	scuolamaterna		44.4903150000000025	11.3706130000000005	via  Vizzani, 56, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
358	Betti Pl. 3	scuolamaterna		44.5011480000000006	11.3447080000000007	via  Irnerio, 2, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
359	De Stefani	scuolamaterna		44.4866460000000004	11.3156490000000005	via  Dotti, 21, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
360	Casaglia	scuolamaterna		44.4764989999999969	11.3072578000000004	via  Casaglia, 39, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
361	Cantalamessa	scuolamaterna		44.4920279999999977	11.3081490000000002	via  dello Sport, 23-25, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
362	Scandellara	scuolamaterna		44.4964050000000029	11.3829820000000002	via  Scandellara, 56, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 07-15, 07-01, 12-08, 12-25, 12-26, -08-: .		
363	Scuola Materna S.Famiglia	scuolamaterna		44.0573199999999972	12.5698519999999991	Via Ennio Coletti, 110 - Rimini RN	Mon, Tue, Wed, Thu, Fri: 0730-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 24556	
364	Scuole Circolo Didattico N. 6 Plessi Di Scuola Materna Statale	scuolamaterna		44.0394000000000005	12.5770230000000005	Via Panaro, 16 - Rimini RN	Mon, Tue, Wed, Thu, Fri: 0730-1630.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 391576	
365	Scuola Materna Paritaria Beata Vergine Del Carmine	scuolamaterna		44.0546239999999969	12.5725920000000002	Via 20 Settembre 1870, 99 - Rimini RN	Mon, Tue, Wed, Thu, Fri: 0730-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 782333	
366	Scuole Materne Private - Casa Di Cristo Re	scuolamaterna		44.0535440000000023	12.5525669999999998	Via Medusa, 22 - Rimini RN	Mon, Tue, Wed, Thu, Fri: 0830-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 770101	
367	La Resurrezione - Scuola Materna Parrocchiale	scuolamaterna		44.0724170000000015	12.5458719999999992	Via della Gazzella, 48 - Rimini RN	Mon, Tue, Wed, Thu, Fri: 0730-1730.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 751308	
368	Congregazione Suore Francescane Missionarie Di Cristo - Scuola Materna S. Francesco	scuolamaterna		44.0519210000000001	12.3209	Viale Roma, 23 - Rimini RN	Mon, Tue, Wed, Thu, Fri: 0730-1630 .	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 734376 	
369	Scuole Circolo Didattico N. 9 Plessi Di Scuola Materna Statale	scuolamaterna		44.0571529999999996	12.5707199999999997	Via Tristano e Isotta, 7 - Rimini RN	Mon, Tue, Wed, Thu, Fri: 0730-1630.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 775060	
370	Fondazione Fabbri Scuola Materna San Lorenzo	scuolamaterna		44.0715489999999974	12.5516269999999999	Viale Santa Margherita Ligure, 1 - Riccione Rimini RN	Mon, Tue, Wed, Thu, Fri: 0830-1630.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 641975	
371	Scuola Materna Privata A.Marvelli Centro Italia	scuolamaterna		44.0518939999999972	12.5911109999999997	Via Lagomaggio, 105 - Rimini RN	Mon, Tue, Wed, Thu, Fri: 0800-1630.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 392276	
372	Scuole Circolo Didattico N. 4 Plessi Di Scuola Materna Statali Giulian	scuolamaterna		44.0662670000000034	12.5647269999999995	Via Giacomo Matteotti, 28 - Rimini RN	Mon, Tue, Wed, Thu, Fri: 0730-1630.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 27192	
374	Congregazione Suore Francescane Scuola Materna Don G. Marconi	scuolamaterna		44.0852160000000026	12.4566130000000008	Via Emilia Vecchia, 215 - Rimini RN	Mon, Tue, Wed, Thu, Fri: 0800-1630.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 620064	
375	Scuola Materna San Paterniano	scuolamaterna		44.0056590000000014	12.4372100000000003	Via Casale, 272 - Verucchio Rimini RN	Mon, Tue, Wed, Thu, Fri: 0800-1630.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 678440	
376	Scuola Materna Don Domenico Masi	scuolamaterna		44.031523	12.6189160000000005	Viale Don Domenico Masi, 67 - Rimini RN	Mon, Tue, Wed, Thu, Fri: 0730-1630.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 478012	
377	Ufficio Bologna 30	posta		44.5161859999999976	11.2832729999999994	Via Sciesa Amatore 1, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1830. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 4143680	
378	Ufficio Bologna 2	posta		44.4936229999999995	11.334441	Via S.Isaia 3, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 6440025	
379	Ufficio Bologna 3	posta		44.4840230000000005	11.3914620000000006	Viale Lincoln Abramo 48/a, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 540946	
380	Ufficio Bologna 1	posta		44.5041920000000033	11.3386610000000001	Via Cairoli 9, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 243425	
381	Ufficio Bologna 6	posta		44.4899529999999999	11.3434629999999999	Via Garibaldi Giuseppe 3/2, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 580769	
382	Ufficio Bologna 32	posta		44.5005740000000003	11.2790789999999994	Via Caduti Di Casteldebole 34/2, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 565118	
383	Ufficio Bologna 4	posta		44.4907439999999994	11.3557550000000003	Strada Maggiore 82/a-b, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 4293231	
384	Ufficio Bologna 5	posta		44.4991979999999998	11.3338199999999993	Via Grimaldi 6, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1830. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 5282731	
385	Ufficio Bologna 27	posta		44.5044600000000017	11.3904580000000006	Via Dell'Industria 2, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 6013098	
386	Ufficio Bologna 28	posta		44.5301240000000007	11.3568449999999999	Via Corazza Natalino 4, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 4170924	
387	Ufficio Bologna 29	posta		44.5223870000000019	11.2637789999999995	Via Normandia 12, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 6414004	
388	Ufficio Bologna 9	posta		44.4975129999999979	11.3484639999999999	Via Delle Belle Arti 9/5, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 2917631	
389	Ufficio Bologna 23	posta		44.5026780000000031	11.3662270000000003	Via Dell'Artigiano 32/a, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 519547	
390	Ufficio Bologna 24	posta		44.4962820000000008	11.2935289999999995	Piazza Bonazzi 6/b, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 6195555	
391	Ufficio Bologna 25	posta		44.5189459999999997	11.3269640000000003	Piazza Da Verazzano Giovanni 6, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 6346586	
392	Ufficio Bologna 26	posta		44.4572509999999994	11.3698029999999992	Via Toscana 140/d, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 489511	
393	Ufficio Bologna Roveri	posta		44.4859050000000025	11.4005360000000007	Via Canova Antonio 19/2, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1830. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 535611	
394	Ufficio Bologna Ponente	posta		44.501263999999999	11.3214140000000008	Via Saffi Aurelio 30/32, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1830. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 5282913	
395	Ufficio Bologna 13	posta		44.4903400000000033	11.3669390000000003	Via Pizzardi 17/a, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 349836	
396	Ufficio Bologna 31	posta		44.4717660000000024	11.3872669999999996	Via Firenze 2, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 454948	
397	Ufficio Bologna 7	posta		44.4859719999999967	11.3545730000000002	Via S.Stefano 140/a, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 344233	
398	Ufficio Bologna 11	posta		44.4814849999999993	11.3370320000000007	Via S.Mamolo 62, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 331034	
399	Ufficio Bologna 10	posta		44.4954869999999971	11.3227949999999993	Via Costa Andrea 71, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 6142017	
400	Ufficio Bologna 14	posta		44.5003039999999999	11.3460210000000004	Piazza dell'Otto Agosto 24, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 250054	
401	Ufficio Bologna Emilia Levante	posta		44.4835229999999981	11.3743770000000008	Via Emilia Levante 7, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1830. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 6246522	
402	Ufficio Bologna 16	posta		44.5078519999999997	11.3430739999999997	Via De Maria Mario 3, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 353596	
403	Ufficio Bologna 15	posta		44.5125110000000035	11.3489079999999998	Via Saliceto 4, Bologna BO, Italy	Mon, Tue, Wed: 0800-1830. Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 352341	
404	Ufficio Bologna 18	posta		44.5038589999999985	11.2980509999999992	Via Vittoria 10/c, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 312064	
405	Ufficio Bologna 17	posta		44.4980040000000017	11.3388249999999999	Via Morgagni 6, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 232183	
406	Ufficio Bologna 36	posta		44.4608530000000002	11.3737720000000007	Via Corelli 23/d, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 477472	
407	Ufficio Bologna 20	posta		44.4726270000000028	11.3699960000000004	Via Delle Armi 1/2/3, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 442404	
408	Ufficio Bologna 34	posta		44.5116849999999999	11.3897480000000009	Via Pirandello Luigi 22, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 6330345	
409	Ufficio Bologna 33	posta		44.5178760000000011	11.3519810000000003	Via Vasari Giorgio 30, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 371063	
410	Ufficio Bologna Centro	posta		44.4916180000000026	11.3449930000000005	Piazza Minghetti 1, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1830. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 230699	
411	Ufficio Bologna Aeroporto	posta		44.5227369999999993	11.2939819999999997	Via Triumvirato 84, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1830. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 6472356	
412	Ufficio Bologna 38	posta		44.5135519999999971	11.4107769999999995	Via Canali Paolo 1, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri, Sat: 0700-1100.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 6331744	
413	Ufficio Bologna 37	posta		44.4941900000000032	11.3465190000000007	Via Pupilli Giancarlo 1, Bologna BO, Italy	Mon: 0800-1930. Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 333066	
414	Ufficio Bologna 22	posta		44.4949099999999973	11.3157709999999998	Via Andrea Costa 154, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 6143686	
415	Ufficio Bologna 35	posta		44.5110299999999981	11.3617810000000006	Piazza Della Costituzione 8, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 352778	
416	Ufficio Bologna 8	posta		44.4908599999999979	11.321256	Via XXI Aprile, 2/4/6, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 6145521	
417	Poste Italiane Spa	posta		44.0624299999999991	12.5689399999999996	Via Alessandro Gambalunga, 40 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0800-1830.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 58811	
418	Ufficio Postale	posta		44.0571430000000035	12.5706989999999994	Largo Giulio Cesare, 1 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0800-1830.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0	
424	Poste Italiane Filiale Di Rimini - Ufficio Postale Di Santa Giustina Di Rimi	posta		44.068361000000003	12.4829030000000003	Via Emilia, 336 - Rimini RN	Tue, Wed, Thu, Fri, Sat: 0800-1330.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 682006	
425	Poste Italiane Spa - Filiale Di Rimini - Centralino	posta		44.0570200000000014	12.5707109999999993	Largo Giulio Cesare, 1 - Rimini RN	Tue, Wed, Thu, Fri, Sat: 0800-1330.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 634211	
426	Poste Italiane Spa - Uff.Postale Rimini 009 Centralino 	posta		44.0439480000000003	12.5674960000000002	Via Euterpe, 9 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0800-1830.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 760411	
427	Ufficio Postale	posta		44.0635959999999969	12.5852850000000007	Piazza Marvelli, 4-5 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0800-1830.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0	
430	Poste Italiane Filiale Di Rimini	posta		44.0701019999999986	12.5779929999999993	Viale Paolo Mantegazza, 2 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0800-1830.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 54399	
431	Poste Italiane - Sportelleria	posta		44.068995000000001	12.5672010000000007	Viale Paolo Mantegazza, 2 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0800-1830.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 54539	
434	Poste Italiane Filiale Di Rimini - Ufficio Postale Di Rimini 006	posta		44.0365170000000035	12.5803329999999995	Viale Tripoli, 4 - Rimini RN	Tue, Wed, Thu, Fri, Sat: 0800-1330.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 390345	
435	UNICREDIT	banca		44.4814835999999971	11.3610171999999991	Via Augusto Murri, 69, 40137 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 429871	
436	UNICREDIT	banca		44.5047307000000032	11.3706963999999999	Via San Donato, 83, 40127 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 633220	
437	UNICREDIT	banca		44.5167537000000024	11.3422958000000005	Via Francesco Barbieri, 56, 40129 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 0957711	
438	UNICREDIT	banca		44.5088525999999973	11.3626088000000003	Viale Aldo Moro, 20, 40127 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 984681	
428	Poste Italiane Filiale Di Rimini - Ufficio Postale Di Torre Pedrera	posta		44.1063279999999978	12.5122660000000003	Viale Nairobi, 20 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Mon: 0800-1330. Sat: 0800-1330.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 720661	
433	Poste Italiane - Filiale Di Rimini - Ufficio Postale Di Viserbe	posta		44.0952029999999979	12.5265559999999994	Viale Silvio Cenci, 4/c - Rimini RN	Tue, Wed, Thu, Fri, Wed: 0800-1330. Sat: 0800-1830.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 722355	
429	Poste Italiane Filiale Di Rimini - Rimini Succ.8 Ufficio Postale Di Rimini	posta		44.0493710000000007	12.5867140000000006	Via Giacinto Gallina, 5 - Rimini RN	Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1330.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 389059	
419	Poste Italiane - Filiale Di Rimini - Ufficio Postale Di Miramar	posta		44.0284600000000026	12.6227739999999997	Viale Guglielmo Marconi, 113 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Mon: 0800-1330. Sat: 0800-1330.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 470011 	
423	Poste Italiane Filiale Di Rimini - Rimini Succ.10	posta		44.0361249999999984	12.5803349999999998	Via Coriano, 58 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Mon:0800-1330. Sat: 0800-1330.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 382129	
421	Poste Italiane - Filiale Di Rimini - Ufficio Postale Di San Lor	posta		44.0048239999999993	12.5712170000000008	Via Montescudo, 349 - Rimini RN	Tue, Thu, Fri, Mon: 0800-1330. Wed: 0800-1330. Sat: 0800-1330.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 730679	
432	Poste Italiane Spa - Ufficio Postale Di Riccione Centro - Centralino	posta		44.0004100000000022	12.6588600000000007	Viale Filippo Corridoni, 13 - Riccione Rimini RN	Mon, Tue, Wed, Thu, Fri: 0800-1330. Sat: 0800-1830.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 473911	
439	UNICREDIT	banca		44.4869450999999998	11.3537545000000009	Via Dante, 1, 40125 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 393999	
440	UNICREDIT	banca		44.4929744000000014	11.3602372999999996	Via Giuseppe Massarenti, 9, 40138 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 636053	
441	UNICREDIT	banca		44.5168030999999971	11.3314412999999998	Via Yuri Gagarin, 13, 40131 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 634598	
442	UNICREDIT	banca		44.503510900000002	11.3150986000000007	Via Emilia Ponente, 12, 40133 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 315811	
443	UNICREDIT	banca		44.4864472000000006	11.3388872000000003	Piazza di Porta San Mamolo, 6/3, 40136 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 581122	
444	UNICREDIT	banca		44.5035381000000001	11.3338359999999998	Via Amedeo Parmeggiani, 6, 40131 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 528791	
445	UNICREDIT	banca		44.4849885	11.3481688999999992	Via Castiglione, 87, 40136 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 644778	
446	UNICREDIT	banca		44.4942423000000034	11.3282942999999996	Viale Carlo Pepoli, 82, 40123 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 6140006	
447	UNICREDIT	banca		44.5040770000000023	11.315061	Largo B. Nigrisoli, 2, 40133 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 313727	
448	UNICREDIT	banca		44.4933466000000024	11.3360629999999993	Piazza Malpighi, 18, 40123 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 335911	
449	UNICREDIT	banca		44.4998372000000018	11.3596907999999992	Via San Donato, 32, 40127 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 244198	
450	UNICREDIT	banca		44.4991928999999971	11.3331143000000001	Piazza Manfredi Azzarita, 7, 40122 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 523044	
451	INTESA SAN PAOLO	banca		44.4942309999999992	11.3446140999999994	Via degli Artieri, 2, 40125 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1330, 1445-1615.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 2912511	
452	UNICREDIT	banca		44.5196100000000001	11.2679560999999993	Via Marco Emilio Lepido, 182, 40132 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 641556	
453	INTESA SAN PAOLO	banca		44.5278581000000031	11.3657427000000002	Via Ferrarese, 156, 40128 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1330, 1445-1615.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .		
454	INTESA SAN PAOLO	banca		44.5258082000000002	11.3439175999999993	Piazza Dei Martiri, 8, 40122 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1330, 1445-1615.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .		
455	MONTE DEI PASCHI DI SIENA	banca		44.5060472999999988	11.3617702999999999	Viale della Repubblica, 23, 40127 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	 051 633841	
456	INTESA SAN PAOLO	banca		44.4665132000000014	11.3709118999999994	Via Toscana, 38, 40141 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1330, 1445-1615.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .		
457	MONTE DEI PASCHI DI SIENA	banca		44.4948017999999976	11.3432358000000004	Via Francesco Rizzoli, 6, 40125 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 658511	
458	MONTE DEI PASCHI DI SIENA	banca		44.4684825000000004	11.3710398000000001	Via Toscana, 32/2, 40141 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 479691	
459	MONTE DEI PASCHI DI SIENA	banca		44.4888643999999971	11.3430713000000001	Piazza dei Tribunali, 6, 40124 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 644951	
460	UNICREDIT	banca		44.4814324000000028	11.3702846999999991	Via Giuseppe Dagnini, 48, 40137 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 623203	
461	MONTE DEI PASCHI DI SIENA	banca		44.4955931000000007	11.3418872000000004	Via Monte Grappa, 3, 40121 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 233856	
462	UNICREDIT	banca		44.4845439999999996	11.3723031999999993	Via Giuseppe Mazzini, 172, 40139 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 347849	
463	UNICREDIT	banca		44.5096513000000016	11.3561428000000006	Via Stalingrado, 26, 40128 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 371951	
464	UNICREDIT	banca		44.492254299999999	11.3639606000000004	Via Giuseppe Massarenti, 100, 40138 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 429931	
465	MONTE DEI PASCHI DI SIENA	banca		44.4817630000000008	11.3605014000000004	Via Augusto Murri, 61, 40137 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 306234	
466	MONTE DEI PASCHI DI SIENA	banca		44.4911349999999999	11.3213668999999992	Via Filippo Turati, 69, 40134 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 614537	
467	MONTE DEI PASCHI DI SIENA	banca		44.4760843999999977	11.3837186999999993	Via Sardegna, 4, 40139 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 624104	
468	UNICREDIT	banca		44.5118609000000021	11.3510790000000004	Via Ferrarese, 85, 40128 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 640773	
469	MONTE DEI PASCHI DI SIENA	banca		44.5090529000000004	11.4612570999999992	Via Galileo Galilei, 6, 40055 Castenaso Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 271072	
470	UNICREDIT	banca		44.493382699999998	11.3832155000000004	Via Giuseppe Massarenti, 179, 40138 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 506801	
471	MONTE DEI PASCHI DI SIENA	banca		44.4775953999999984	11.3682785000000006	Via Giuseppe Dagnini, 9, 40137 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 623662	
472	MONTE DEI PASCHI DI SIENA	banca		44.4937949999999987	11.3457840000000001	Via Caprarie, 3/A, Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 230445	
473	UNICREDIT	banca		44.5009973000000016	11.3216406000000003	Via Aurelio Saffi, 28, 40131 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 095201	
474	UNICREDIT	banca		44.4768821999999986	11.3663995999999994	Via Augusto Murri, 143, 40137 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 445371	
475	UNICREDIT	banca		44.4949111999999971	11.3261467000000007	Via Andrea Costa, 22, 40134 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 614393	
476	UNICREDIT	banca		44.510417799999999	11.3469300999999998	Via Giacomo Matteotti, 36, 40129 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 415521	
477	UNICREDIT	banca		44.4940149000000034	11.3517772000000008	Piazza Aldrovandi, 12, 40125 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 275741	
478	UNICREDIT	banca		44.4954869000000031	11.3540919999999996	Via Belmeloro, 1, 40126 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 230490	
479	UNICREDIT	banca		44.4987822000000008	11.3384117	Via Guglielmo Marconi, 43, 40122 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 275791	
480	UNICREDIT	banca		44.4917555999999976	11.3429470000000006	Piazza Galvani, 3, 40124 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 275521	
481	UNICREDIT	banca		44.4935639999999992	11.3417767000000005	Via 4 Novembre, 10, 40123 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 275631	
482	UNICREDIT	banca		44.5002409000000014	11.3486405000000001	Via Irnerio, 12, 40126 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 984121	
483	UNICREDIT	banca		44.494995099999997	11.3420289000000007	Via Ugo Bassi, 1, 40121 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 640811	
484	MONTE DEI PASCHI DI SIENA	banca		44.4927044000000009	11.3696303000000007	Via Giuseppe Massarenti, 60, 40138 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 533073	
485	UNICREDIT	banca		44.4881182999999965	11.3611763000000003	Piazza Trento e Trieste, 5/2, 40137 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 429861	
486	UNICREDIT	banca		44.4943608000000026	11.3457787000000003	Via Francesco Rizzoli, 34, 40125 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 640811	
487	UNICREDIT	banca		44.4889926999999972	11.2975736999999992	Via Don Luigi Sturzo, 33, 40135 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 439311	
488	UNICREDIT	banca		44.4767548000000019	11.3860452999999993	Via Bellaria, 37, 40139 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 540284	
489	UNICREDIT	banca		44.493000600000002	11.3005679000000008	Via della Barca, 3, 40133 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 439331	
490	UNICREDIT	banca		44.5087142	11.2947355999999992	Via Emilia Ponente, 211, 40133 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 414151	
491	UNICREDIT	banca		44.5106796000000031	11.3972897999999994	Via Alberto Trauzzi, 15, 40127 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 633066	
492	MONTE DEI PASCHI DI SIENA	banca		44.5022103000000016	11.3699460999999999	Via Eleonora Duse, 16, 40127 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 505456	
493	UNICREDIT	banca		44.4950311999999997	11.4005588000000007	Via Enrico Mattei, 22, 40138 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 603981	
494	UNICREDIT	banca		44.4628048000000007	11.3708573000000008	Via Toscana, 58, 40141 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 483861	
495	MONTE DEI PASCHI DI SIENA	banca		44.5089710999999966	11.3469118000000009	Via Giacomo Matteotti, 33, 40129 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 362959	
496	MONTE DEI PASCHI DI SIENA	banca		44.4964379999999977	11.3430079999999993	Via dell'Indipendenza, 10, 40121 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 643811	
497	UNICREDIT	banca		44.5464397000000005	11.3564001999999995	Via Genuzio Bentini, 35, 40128 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 417291	
498	UNICREDIT	banca		44.5160018999999991	11.2789775999999993	Via Marco Emilio Lepido, 8, 40132 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 641400	
499	UNICREDIT	banca		44.5042690000000007	11.3655200000000001	Via Tommaso Salvini, 12, 40127 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 502079	
500	MONTE DEI PASCHI DI SIENA	banca		44.5039281000000031	11.3491184000000001	Viale Angelo Masini, 1/2, 40126 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 639075	
501	MONTE DEI PASCHI DI SIENA	banca		44.4998330000000024	11.3251916999999995	Via Aurelio Saffi, 10, 40131 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 555403	
502	MONTE DEI PASCHI DI SIENA	banca		44.4946094000000016	11.3481951999999993	Via San Vitale, 24, 40125 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 260891	
503	MONTE DEI PASCHI DI SIENA	banca		44.4992435999999998	11.3515394999999994	Via Irnerio, 43, 40126 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 422671	
504	UNICREDIT	banca		44.4959607999999989	11.3428997000000003	Via dell'Indipendenza, 11, 40121 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 6408111	
505	MONTE DEI PASCHI DI SIENA	banca		44.5068193999999977	11.3621133000000007	Via Caduti della Via Fani, 15, 40127 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 505550	
506	MONTE DEI PASCHI DI SIENA	banca		44.5031964000000002	11.3160507999999993	Via Emilia Ponente, 17, 40133 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 351901	
507	MONTE DEI PASCHI DI SIENA	banca		44.5019064000000029	11.3530198000000002	Piazza di Porta Mascarella, 7, 40126 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 240770	
508	MONTE DEI PASCHI DI SIENA	banca		44.495980000000003	11.2916101999999992	Via della Barca, 42, 40133 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 619948	
509	UNICREDIT	banca		44.480716000000001	11.3425999999999991	Via Giulio Cesare Pupilli, 1, 40136 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 6109011	
510	MONTE DEI PASCHI DI SIENA	banca		44.4964379999999977	11.3430079999999993	Via dell'Indipendenza, 10, 40121 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 643811	
511	MONTE DEI PASCHI DI SIENA	banca		44.4989800000000031	11.3389437999999991	Via Riva di Reno, 65, 40122 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 221034	
512	MONTE DEI PASCHI DI SIENA	banca		44.4952441000000007	11.3479682999999998	Via Zamboni, 11, 40126 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 207111	
513	UNICREDIT	banca		44.4994374999999991	11.3203727000000001	Via Vittorio Veneto, 13, 40131 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 614215	
514	MONTE DEI PASCHI DI SIENA	banca		44.503937999999998	11.3450019999999991	Piazza XX Settembre, 40121 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 247561	
515	UNICREDIT	banca		44.5124589999999998	11.2872827999999998	Via Emilia Ponente, 280, 40132 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 617931	
516	MONTE DEI PASCHI DI SIENA	banca		44.4989800000000031	11.3389437999999991	Via Riva di Reno, 65, 40122 Bologna, Italy	Mon, Tue, Wed, Thu, Fri: 0820-1320, 1430-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051 221034	
517	Museo Storico del Soldatino M. Massacesi	museo		44.4693047000000021	11.3710527999999993	Villa Mazzacorati - Via Toscana, 19, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri, Sat, Sun: 0900-2130. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/595158-051/6149574	
518	Museo Ducati	museo		44.5162132999999969	11.2690021999999992	Borgo Panigale - Via Cavaliere Ducati, 3, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri, Sat: 0800-1930. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/6413343	
519	Museo Morandi	museo		44.4949808000000004	11.3434653000000001	Palazzo d’Accursio, 6, Bologna BO, Italy	Tue, Wed, Thu, Fri, Sat, San: 0830-1830. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	 051/203646 – 203386 - 203403	
520	Pinacoteca Nazionale	museo		44.4977060000000009	11.3532045000000004	Via delle Belle Arti, 56, Bologna BO, Italy	Tue, Wed, Thu, Fri, Sat, San: 0830-1830. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051-4209411	
521	Museo Ebraico	museo		44.4959910999999977	11.34788	Via Valdonica, 1/5, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri, Sun: 0830-1930. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051-2911289	
523	Museo Ostetrico G. A. Galli	museo		44.4963821999999993	11.3529677000000007	Museo di Palazzo Poggi - Università degli Studi di Bologna - Via Zamboni, 33, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri, Sat, Sun: 0900-1930. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/2099398	
528	Museo della Sanità e dell'Assistenza	museo		44.4933133999999981	11.3443681000000005	Via Clavature, 8, Bologna BO, Italy	Tue, Wed, Thu, Fri, Sat, Sun: 0800-2030. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/230260 	
529	Museo Civico del Risorgimento	museo		44.489670799999999	11.3576682000000009	Piazza G. Carducci, 5, Bologna BO, Italy	Tue, Wed, Thu, Fri, Sat: 0800-1900. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/347592-051/343952	
530	Museo delle Navi e delle Antiche Carte Geografiche	museo		44.4963821999999993	11.3529677000000007	Museo di Palazzo Poggi - Università degli Studi di Bologna - Via Zamboni, 33, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1830. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/2099398-2099610	
524	Collezioni Comunali d'Arte	museo		44.4939532	11.3424297000000003	Piazza Maggiore, 6, Bologna BO, Italy	Tue, Wed, Thu, Fri, Sat, San: 0830-1230, 1530-1930. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/203526 – 203153	
525	Museo Civico Archeologico	museo		44.4929253000000031	11.3435713000000007	Via dell’Archiginnasio, 2, Bologna BO, Italy	Tue, Wed, Thu, Fri, Sat, Sun: 0830-1230, 1530-1930. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051-2757211	
526	Museo Storico Didattico della Tappezzeria\t	museo		44.4886478999999966	11.3160252000000003	Via Casaglia, 3, Bologna BO, Italy	Tue, Wed, Thu, Fri, Sat, Sun: 0830-1230, 1530-1930. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/6145512	
527	Museo Tattile di Pittura Antica e Moderna	museo		44.4863375999999988	11.3482140000000005	Via Castiglione, 71, Bologna BO, Italy	Fri, Sat: 0830-1230, 1530-1930. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051-332090	
531	Specola e Museo di Astronomia	museo		44.4963821999999993	11.3529677000000007	Dipartimento di Astronomia dell'Università di Bologna - Via Zamboni, 33, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri, Sat, Sun: 0800-1930. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/2099360-2099610	
532	Museo di Palazzo Pepoli Campogrande	museo		44.4926932999999991	11.3461830999999993	Via Castiglione, 7, Bologna BO, Italy	Sat, Sun: 0930-2000. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/229858-239031	
533	Donazione Putti e Raccolta Rizzoli-Codivilla	museo		44.480716000000001	11.3425996999999992	Biblioteche Scientifiche - Istituti Ortopedici Rizzoli - Via Pupilli, 1, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri, Sat: 0800-1930. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/6366315	
534	Museo dello Studio del Nono Centenario	museo		44.4963821999999993	11.3529677000000007	Museo di Palazzo Poggi - Università degli Studi di Bologna - Via Zamboni, 33, Bologna BO, Italy	Visitabile su richiesta. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/2099604	
535	Museo di Anatomia Umana Normale	museo		44.4963821999999993	11.3529677000000007	Museo di Palazzo Poggi - Università degli Studi di Bologna - Via Zamboni, 33, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1930. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/2099610	
536	Museo Aldrovandi	museo		44.4963821999999993	11.3529677000000007	Museo di Palazzo Poggi - Università di Bologna - Via Zamboni, 33, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri, Sat, Sun: 0800-2100. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/20993360	
537	Civico Museo Bibliografico Musicale	museo		44.4953132999999994	11.3489647999999992	Piazza Rossini, 2, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri:0800-2000. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/221117	
538	Museo di Architettura Militare	museo		44.4963821999999993	11.3529677000000007	Museo di Palazzo Poggi - Università di Bologna - Via Zamboni, 33, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1930. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/259021-051/259030	
539	Museo di Zoologia	museo		44.4961575000000025	11.3541650000000001	Dipartimento di Biologia Evoluzionistica Sperimentale - Università di Bologna - Via Selmi, 3, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri, Sat, Sun: 0800-1930. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/2094248-2094140	
540	Museo di S. Giuseppe	museo		44.4895394999999994	11.3257262999999995	Convento di S. Giuseppe - Via Bellinzona, 6, Bologna BO, Italy	Fri: 0830-1930 . 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/6446406-3397511	
541	Museo Civico Medievale	museo		44.4964616999999976	11.3423093999999995	Palazzo Fava-Ghisilardi - Via Manzoni, 4, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri, Sat, Sun: 0830-1200. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/2193916-2193930	
542	Museo di S. Domenico	museo		44.4897269000000009	11.3440069999999995	Basilica di S. Domenico - Piazza S. Domenico, 13, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri, Sat, Sun: 0900-1830 . 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/6400411	
543	Museo della Santa	museo		44.4888290999999967	11.3397377000000006	Chiesa e Monumento del Corpus Domini - Via Tagliapietre, 21, Bologna BO, Italy	Tue, Thu, Sat, Sun: 0830-1830. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/331274	
544	Museo Civico d'Arte industriale e Galleria Davia Bargellini	museo		44.4922869999999975	11.3518861999999991	Strada Maggiore, 44, Bologna BO, Italy	Tue, Wed, Thu, Fri, Sat, Sun: 0830-1930. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/236708	
545	Museo di S. Petronio	museo		44.4921645000000012	11.3432011999999993	Basilica di S. Petronio - Piazza Galvani, 5, Bologna BO, Italy	Wed, Thu, Fri, Sat, Sun: 0830-1930. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/225442	
546	Museo Marsiliano	museo		44.4970799000000028	11.3528748999999998	Biblioteca Universitaria - Via Zamboni, 33, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri, Sat: 0830-1830 . 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/244564-243420	
547	Museo di S. Stefano	museo		44.4921047999999999	11.3484262999999999	Basilica di S. Stefano - Via Santo Stefano, 24, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri, Sat, Sun: 0830-1930. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/223256	
548	Casa Carducci\t	museo		44.489670799999999	11.3576682000000009	Piazza G. Carducci, 5, Bologna BO, Italy	Tue, Wed, Thu, Fri, Sat, Sun: 0930-1200. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/347592	
549	Museo di Anatomia Patologica C. Taruffi	museo		44.4941902999999996	11.3465185000000002	Istituto di Anatomia e Istologia Patologica - Policlinico S. Orsola - Via G. Massarenti, 9, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri, Sat: 0800-1800. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/242217	
550	Museo di Fisica	museo		44.4992584000000022	11.3528619000000006	Dipartimento di Fisica - Università di Bologna - Via Irnerio, 46, Bologna BO, Italy	Visitabile su richiesta. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/2091169	
551	Museo di Antropologia	museo		44.4961575000000025	11.3541650000000001	Dipartimento di Biologia Evoluzionistica Sperimentale - Università di Bologna - Via Selmi, 3, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-2100. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/2094191-2094196	
552	Museo di Antropologia\tScientifici	museo		44.4961575000000025	11.3541650000000001	Dipartimento di Biologia Evoluzionistica Sperimentale - Università di Bologna - Via Selmi, 3, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-2100. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:0000-2400.	051/2094191-2094196	
553	Museo Apistico	museo		44.5249233999999987	11.3500116999999996	Località Corticella - Istituto Nazionale di Apicultura - Via di Saliceto, 80, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0800-1830. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/353103	
554	Museo Paleontologico e Geologico G. Capellini\t	museo		44.4941902999999996	11.3465185000000002	Dipartimento di Scienze della Terra e Geologico-Ambientali - Via Zamboni, 63, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-2000. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/2094555	
555	Museo di Mineralogia e Petrografia L. Bombicci	museo		44.4941902999999996	11.3465185000000002	Dipartimento di Scienze della Terra e Geologico-Ambientali - Università di Bologna - Piazza di Porta S. Donato, 1, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-2000. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/2094926	
556	Museo di Anatomia Comparata	museo		44.4961575000000025	11.3541650000000001	Dipartimento di Biologia Evoluzionistica Sperimentale - Università di Bologna - Via Selmi, 3, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri: 0830-1930. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/2094243 	
557	Galleria d'Arte Moderna	museo		44.511854900000003	11.3614700000000006	Piazza Costituzione, 3, Bologna BO, Italy	Tue, Wed, Thu, Fri, Sat, Sun: 0800-1830. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/502859	
558	Museo Mille Voci e Mille Suoni	museo		44.5006850999999983	11.3201263000000001	Via Col di Lana, 7/n, Bologna BO, Italy	Visitabile a richiesta. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/6491008	
4	Palestra Athena - Ginnastica Bodybuilding Sauna	palestra		44.0639480000000034	12.5674050000000008	Via Clodia, 33 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0930-1230, 1430-1900.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 53336	
420	Ufficio Postale	posta		44.0619950000000031	12.5647540000000006	Via Ennio Coletti, 19 - Rimini RN	Tue, Wed, Fri, Mon: 0800-1330. Thu: 0800-1330. Sat: 0800-1330.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 24071	
522	Museo del Patrimonio Industriale	museo		44.522051900000001	11.3314696000000001	Fornace Galotti – Via della Beverara, 123, Bologna BO, Italy	Tue, Wed, Thu, Fri,Sat, Sun: 0830-1230, 1530-1930. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051/635611 – 6356602	
559	Museo dell'Evoluzione	museo		44.4961575000000025	11.3541650000000001	Via Selmi, 3, Bologna BO, Italy	Mon, Tue, Wed, Thu, Fri, Sat, Sun: 0830-1230, 1530-1930. 	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26:.	051-2094248	
422	Poste Italiane S.P.A. - Filiale Di Rimini-Rimini Succ.9	posta		44.0539879999999968	12.5677800000000008	Via Euterpe, 3 - Rimini RN	Wed, Thu, Fri, Mon: 0800-1330. Tue: 0800-1330. Sat: 0800-1330.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 776100	
373	Fondazione Fabbri Scuola Materna San Lorenzo	scuolamaterna		44.0033799999999999	12.6320350000000001	Viale Santa Margherita Ligure, 1 - Riccione Rimini RN	Mon, Tue, Wed, Thu, Fri: 0800-1700.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 641975	
110	Co.De.As. Di Manuelli Agostino e C. (S.N.C.)	supermarket		44.0441670000000016	12.5820059999999998	Via Giaime Pintor, 7 - Rimini RN	Mon, Tue, Wed, Thu, Fri, Sat: 0830-2030. Sun: 0830-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 383617	
138	Supermercato Superstore Conad Rio Agina Di Bernardini Renato, Cecchini Giorgio e C. Snc	supermarket		43.9780159999999967	12.6888339999999999	V Don Milani, 5 - Misano Adriatico 47843 RN	Tue, Wed, Thu, Sat: 0800-1930.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	0541 612432	
565	Piazza San Francesco	colonnina		44.4952373303718005	11.3353708472241994	Piazza di San Francesco, 8				Una colonnina in fregio al civico 8, sul marciapiede a fianco del posto auto in linea
566	Via di Saliceto	colonnina		44.5126593914582003	11.3496685581798005	Via di Saliceto				all'interno del parcheggio adiacente il giardino Guido Rossa,una colonnina su area verde a metà del terzo stallo sosta, quello dopo gli stalli adibiti a persone con ridotte capacità motorie
567	Via Boldrini	colonnina		44.5041347112363965	11.3431198091866996	Via Gramsci, 12				In fregio al civico 12 di via Gramsci, due colonnine sul marciapiede rispettivamente a metà dei due stalli auto a lisca di pesce dopo gli stalli auto riservati a mezzi USL
568	Viale XII Giugno	colonnina		44.4880585669755035	11.3438992174431004	Via Vascelli, 2				Una colonnina fronte al civico 2 di via Vascelli, su marciapiede a fianco del primo posto in linea tra alberature dopo fermata ATC
569	Via Augusto Righi	colonnina		44.4990368674923999	11.3450234298331001	Via Augusto Righi, 14				In fregio al civico 14, in mezzo a stallo auto tra alberature a lisca di pesce, su marciapiede
570	Piazza di Porta Mascarella	colonnina		44.5018613379725991	11.3529916868442005	Piazza di Porta Mascarella, 7				In fregio al civico 7 (via Pichat angolo via Mascarella), su sede stradale a fianco del primo posto auto a pettine
571	Via Pietro Mainoldi	colonnina		44.4844311421796021	11.3757924496628	Via Pietro Mainoldi				Una colonnina a lato del posto auto in linea che rimane sul lato sinistro dell'ingresso del parcheggio coperto del centro commerciale (ex Dima) a fianco dello stallo riservato alle persone con ridotte capacità motorie
572	Piazza dei Martiri	colonnina		44.5026575031789022	11.3400203304331004	Piazza dei Martiri				su marciapiede a fianco del primo stallo sosta in linea
573	Piazza F.D. Roosvelt	colonnina		44.4941133402364031	11.3400235826283993	Piazza F.D. Roosvelt				in prossimità all'intersezione con via IV Novembre, una colonnina in sostituzione ad un dissuasore esistente che delimita l'area di sosta dal percorso pedonale, su sede stradale a fianco del posto auto a pettine
574	Via San Giacomo	colonnina		44.496380584444303	11.3555125316539005	Via San Giacomo, 9/2				In fregio al civico 9/2, una colonnina sul marciapiede a fianco del primo stallo auto in linea dopo gli stalli riservati motocicli
575	Via Ugo Foscolo	colonnina		44.4918573466986018	11.3301029277310992	via Ugo Foscolo, 7				Sul marciapiede a fianco dello stallo sosta in linea precedente l'accesso al civico 7
576	Piazza della Pace	colonnina		44.4919594864106003	11.3119244534296008	Piazza della Pace				Due colonnine su area verde, lato parco i primi due posti auto a pettine all'intersezione con via XXI Aprile 1945
577	Via Dante Alighieri	colonnina		44.4872900558954001	11.3566510864256003	Via Dante Alighieri, 14				Su marciapiede a fianco del primo stallo sosta in linea
579	Via Fioravanti	colonnina		44.5090460863899011	11.3404663812777002	Via Fioravanti				All'intersezione con via Tiarini dopo posto Handicap
578	Via Riva Reno	colonnina		44.4990463943890973	11.3387295859215005	Via Riva Reno, 60				Sul marciapiede fronte lo stallo sosta in linea precedente l'intersezione con via Brugnoli
580	Via Aldo Moro	colonnina		44.5093880784229015	11.3624471913595002	Via Aldo Moro, 18				
\.


--
-- Name: locations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('locations_id_seq', 580, true);


--
-- Data for Name: suggest; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY suggest (id, msg, category, email) FROM stdin;
5	Ci sarebbe bene anche la visualizzazione satellitare sulla mappa. Bravi bella l'idea 	suggerimento	None
6	None	None	None
\.


--
-- Name: suggest_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('suggest_id_seq', 6, true);


--
-- Data for Name: waiting; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY waiting (id, name, category, subcategory, latitude, longitude, address, opening, closing, tel, note) FROM stdin;
20	Pakistano	alimentari	None	44.5060672061287192	11.3734345883131027	via San Donato, 122	Mon,Tue,Wed,Thu,Fri,Sat,Sun: 0900-2200.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	None	None
23	Bolpetta	ristorante	None	44.4935094198190555	11.3468716666102409	via santo stefano,6	Mon,Tue,Wed,Thu,Fri,Sat,Sun: 1200-1600, 1800-2359.	None	None	None
32	Laboratorio Ranzani	universita	Informatica	44.5011544644117336	11.3587867096066475	Via Camillo Ranzani, 14/C	Mon,Tue,Wed,Thu,Fri: 0900-1845.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	None	None
30	Laboratorio Ercolani	universita	Informatica	44.4974506840957105	11.3562111184000969	via mura anteo zamboni	Mon,Tue,Wed,Thu,Fri: 0900-1945.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	None	None
28	Coop Adriatica	supermarket	None	44.6628882240654974	11.1351813375950002	Via Sibirani, 2 	Mon,Tue,Wed,Thu,Fri,Sat: 0730-1930.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	051/8906946	None
33	Osteria Al Gallo	ristorante	ristorante/pizzeria	45.6067910000000012	10.5072659999999996	Via Santa Firmina, 25	Tue,Wed,Thu,Fri,Sat: 1800-2359. Sun: 1130-1500, 1800-2359.	None	0365-525944	http://www.osteriaalgallo.it/
34	Spedali Civili	ospedale	None	45.5570659250485974	10.2268492430448994	None	None	None	None	None
38	Ospedale Maggiore	ospedale	None	44.505531355999679	11.3140082359313965	Via Bartolo Nigrisoli,2 Bologna	None	None	051-6478111	None
37	Raspibo	hobby	hackmeeting	44.4872069091108031	11.2873276323079992	via canonici renani, 8 Casalecchio di Reno	None	None	None	None
31	Cobacabana	bar	None	39.511474347467697	16.9263770431279994	None	None	None	None	None
39	Ospedale Sant'Orsola - Malpighi	ospedale	None	44.4920885382899698	11.3605234399437904	Via Pietro Alberoni, 15 Bologna	None	None	None	None
40	MOTONAUTICA ZANCA	negozio	None	45.5996990316064128	10.5190326645970345	via Pietro da Salò 113	None	None	036543476	None
41	SCUOLA INFANZIA	scuolamaterna	None	45.5708514449100335	10.5310415849089622	Via xxx Settembre 10	Sat,Sun: 0745-1600.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	None	None
42	EUROSPIN	supermarket	None	45.5681037184534077	10.5307287722826004	Via Nazionale 	Mon,Tue,Wed,Thu,Fri,Sat,Sun: 0830-1930.	None	None	None
43	CAPRICE EN TETE	negozio	PARRUCCHIERA	45.6060361321841228	10.5213165655732155	None	Mon: 0815-1800.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	036543653	None
44	TRANQUILLI GIOIELLERIA	negozio	GIOIELLERIA	45.6067116470276801	10.5267319455742836	Via San Carlo 	Mon,Tue,Wed,Thu,Fri,Sat: 0930-1230, 1500-1930.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	036520534	None
45	Enel\n	ufficio	None	40.6721818778223678	16.5886688232421875	None	None	None	None	None
46	Esselunga	supermarket	None	43.9371591758384668	10.9409116208553314	None	None	None	None	None
47	pistoia	supermarket	None	43.9400978227689265	10.9345095232129097	None	None	None	None	None
48	Leoncavallo Spazio Pubblico Autogestito	discoteca	None	45.5014628034363824	9.20801583677530289	via watteau, 7 20125 milano	None	None	02-36510287	None
49	Stock Calzature	negozio	None	45.5416032186868023	10.5313919484615006	via trevisago, 33/G, 25080 Moniga	Mon,Tue,Wed,Thu,Fri,Sat: 1015-1225, 1500-1930. Sun: 1700-1900.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	333-7182133	None
50	conad	supermarket	None	44.7333335342102814	10.6199232861398993	None	None	None	None	None
51	Bella Taranto	pizzeria	asporto	44.5019945259595033	11.3626688718795776	via tartini 2	Mon,Tue,Wed,Thu,Fri,Sat,Sun: 1130-1500, 1900-2359, 0000-0330.	None	051-6333865	None
52	ld market	supermarket	None	45.7185655851055799	9.28337451070547104	None	None	None	None	None
53	Self	hobby	None	45.0440031940103225	7.67737839370965958	c.so Moncalieri 	Mon,Tue,Wed,Thu,Fri,Sat,Sun: 0830-1030.	None	None	None
54	Gabriele 	palestra	casa 	45.9104126393713798	8.69138818234205246	via campi 2d	None	None	None	None
55	Antoniodimaria	supermarket	None	44.4312511715692153	8.8388701155699998	None	None	None	None	\n
56	Doro	scuolamaterna	None	44.4315250647173983	8.83961945772171021	None	None	None	None	None
57	enna	supermarket	None	44.4866902600670073	11.350603960454464	None	None	None	None	None
58	sassari	ufficio	comunale	40.7293714115926235	8.56763541698455811	None	None	None	None	None
59	Stadio Olimpico	sport		41.9338860000000011	12.4547860000000004	Piazzale del Foro Italico, 00135 Roma	None	None	(+39)06-36851	None
60	eurospin	supermarket	None	43.4519312077681548	11.8800743669271469	None	None	None	None	None
61	ukraina	supermarket	None	50.9841558806880641	32.2304947301745415	None	None	None	None	None
62	Godiva	bar	None	45.5576481264615296	10.5330891162157059	Via Campagnola, 34 	None	None	None	None
63	gambin	ristorante	None	44.1279983417144948	9.99069448560476303	None	None	None	None	None
64	Giugliano	supermarket	None	40.8269995975441091	14.5144880935549754	None	None	None	None	None
65	Freccia Rossa	supermarket	Centro Commerciale 	45.5332989784106985	10.2064839005469992	Viale Italia, 31 Brescia 25126	Mon,Tue,Wed,Thu,Fri,Sat: 0900-2200. Sun: 1000-2100.	None	030-2817911	Email: info@adm.freccia-rossa.it
67	Accademia Belle Arti Santa Giulia	universita	None	45.551013255403376	10.2137382701039314	None	None	None	None	None
69	fratelli sacchi	ristorante	None	40.3172207398264462	9.31692827492952347	monte ottobre	None	None	None	None
70	ristorante italia	ristorante	None	40.3237517522762801	9.31442979723215103	via mannironi	None	None	38083	None
71	san francesco	ospedale	None	40.3247767589038446	9.31648973375558853	None	None	None	None	None
74	coop	supermarket	None	44.4866271137589493	11.2125617265701294	None	None	None	None	None
68	teatro eliseo	teatro	teatro	40.3228501936816031	9.33485414832830074	via roma	None	None	None	None
75	Fobap	hotel	ostello\n	45.6339508661636017	10.5996823310851997	None	None	None	None	Circuito del Garda Kayak
76	Polisportiva Zola	sport	None	44.5006840916150281	11.188201904296875	Via Cellini, 6 Zola Predosa (BO) 40069	None	None	051-759176	None
72	ilaria alpi	sport	tennis	44.5010359999999991	11.1886080000000003	via matilde di canossa, zola predosa (BO)	None	None	None	None
77	AIDO LAZIZE	sport	CIRCUITO DEL GARDA LAYAK	45.5082736356538859	10.7333867624402046	VIA ROMA	None	None	None	None
78	marco	supermarket	None	45.5324527746224561	9.22783836722373962	None	None	None	None	None
79	de carli	farmacia	None	45.5254682301283609	9.23073314130306244	None	None	None	None	None
81	ufficio postale	posta	None	45.529486850783897	9.23034388571977971	None	None	None	None	None
82	Mirto 	bar	None	38.07611357768603	13.2947119697928429	None	None	None	None	None
83	Università cattolica del sacro cuore	universita	None	45.5377395193956076	10.2242478355765343	via trieste 17	None	None	None	None
84	lino	farmacia	None	40.828351546300695	14.209311380982399	None	None	None	None	None
85	poste	posta	None	45.8564464485316066	8.86557519435882568	None	None	None	None	None
86	santa Lucia di Piave\n\n\n\n  	supermarket	None	45.8941518651735905	12.4128234386444092	None	None	None	None	None
87	taqui's bar	bar	pub	45.6369115108866055	10.6058088317513466	None	Thu,Fri,Sat,Sun: 0830-1230.	None	None	None
88	taqui's bar/pub	bar	None	45.6404486538262475	10.6086469441652298	None	None	None	None	None
89	agenzia immobiliare	ufficio	None	37.5356056960044526	15.0799949839711207	None	None	None	None	None
90	contrada sanguinello 23 falerna\n\n	benzinaio	None	38.8361872547147868	16.6431424766778946	None	None	None	None	None
91	Piero\n	farmacia	None	45.5727623581256651	9.11518894135951996	None	None	None	None	None
92	pedrocchino	ristorante	None	45.9062218538581632	12.5003905221819878	None	None	None	None	None
93	Trr	benzinaio	None	45.3212067410592567	11.9004806131124496	None	None	None	None	\n\n\n
94	taqui's	bar	None	45.6408016760510407	10.6096557900309563	None	None	None	None	None
95	Fll	farmacia	None	45.5887711533022895	9.16091926395893097	None	None	None	None	None
96	coop	supermarket	None	42.9407957566623963	10.5183567479252815	None	None	None	None	None
97	io	supermarket	None	40.6875509474991404	16.9787756726145744	None	None	None	None	None
98	rizzo 	farmacia	None	40.6335467676162807	17.9349811747670174	None	None	None	None	None
99	\ncerignola	supermarket	None	41.25672101530688	15.8971319720149022	None	None	None	None	None
100	via colleferro	supermarket	None	41.2567487405815925	15.8969522640109062	None	None	None	None	\n\n\n
101	cerignola	supermarket	None	41.2566267492848411	15.8967594802379626	None	None	None	None	None
102	gm	supermarket	None	41.2571192499414323	15.8977388218045235	None	None	None	None	None
103	domi	supermarket	None	41.2566711097827437	15.8968526870012283	via colleferro	None	None	None	None
104	cerignola	supermarket	None	41.2611097797716937	15.8987091109156626	None	None	None	None	None
105	cerignola	bar	None	41.2566143989135909	15.896476171910761	None	None	None	None	None
106	cerignola	bar	None	41.2568825778785566	15.8974162861704826	None	None	None	None	None
107	cerignola	bar	None	41.257277786977852	15.8968050777912158	via colleferro	None	None	None	None
108	cerignola	supermarket	None	41.259831213641597	15.903640016913414	via colleferro	None	None	None	None
109	me	supermarket	None	41.7794288597093484	12.4428031593561172	None	None	None	None	None
110	geometra	ufficio	geometra	43.4558112743704186	11.8912400677800179	None	None	None	None	None
111	farmacia	supermarket	None	44.1564840028244987	8.23633801192045212	None	None	None	None	None
112	vivaio fiori	supermarket	None	43.9246402940002412	8.10504455119371414	None	None	None	None	None
113	vivaio	negozio	fiori	43.9265518473386365	8.10766573995351791	san bartolomeo a mare	None	None	None	None
114	gravina di Puglia 	tabacchi	None	40.8142256322939829	16.4195900782942772	None	None	None	None	None
115	Altamura 	supermarket	None	44.4943139568103732	11.3439789041876793	None	None	None	None	None
116	pieve di coriano	ospedale	None	45.0717329530400548	11.1349835246801376	None	None	None	None	None
117	My	supermarket	None	44.1137338681220257	9.83631324023008347	None	None	None	None	None
118	Toselli 	bar	None	44.8213775561088781	11.626463457942009	None	None	None	None	None
119	bed & breakfast\n\n\n	hotel	None	41.7064691713291111	15.7269330695271492	None	None	None	None	None
120	san Giovanni rotondo	hotel	None	37.568195282326613	14.2727151140570641	None	None	None	None	None
121	D+	supermarket	None	45.0474269187792942	11.1672783270478249	None	None	None	None	None
122	monica	supermarket	milano	45.3530924080666082	9.22808445990085602	Milano	None	None	None	None
123	monica	farmacia	None	45.3942536656435536	9.14751794189214706	None	None	None	None	None
124	farmacia vastelletto monferrato\n	supermarket	None	44.9344172177655992	8.54821421205997467	None	None	None	None	None
125	castelletto	supermarket	None	44.9653041590680473	8.55653408914804459	None	None	None	None	None
126	:	supermarket	None	45.1585607735420638	9.40976053476333618	None	None	None	None	None
127	carfour market	supermarket	None	38.1669376339593214	13.3289268985390663	None	None	None	None	None
128	farmacia	supermarket	None	38.1662456842056628	13.3282164484262466	None	None	None	None	None
129	farmacia	farmacia	None	38.1679451010570929	13.3275710418820381	None	None	None	None	None
130	tulone	farmacia	2eeghxwk1jgp0b4fuqctmstn	38.1751780528900113	13.3186231926083565	2eeghxwk1jgp0b4fuqctmstn	None	None	2w1p04	2eeghxwk1jgp0b4fuqctmstn
131	hotel cinzia	hotel	None	45.3033584039219477	8.42983156442642212	None	None	None	None	None
132	pizzeria 	supermarket	None	43.5616560797709056	11.8517106771469116	None	None	None	None	None
133	benzinaio	supermarket	None	45.7702503926355533	9.08356603235006332	None	None	None	None	None
134	Bennet	supermarket	None	45.7707440849274221	9.08205963671207428	None	None	None	None	None
135	Bar sosta Malcesine 	supermarket	Bar	45.6997891120543613	10.7593374699354172	None	None	None	None	None
136	gpl	benzinaio	None	40.8374800940999592	14.1661009937524796	None	None	None	None	None
137	unicredit	banca	None	39.260708787553483	9.13699161261320114	None	None	None	None	None
138	Peschiera aido	supermarket	None	45.4380758925855162	10.6958841159939766	None	None	None	None	None
139	Idraulica 	negozio	None	42.0003248991587768	12.6299318298697472	None	None	None	None	None
140	bolzaneto genova 	supermarket	None	44.4588124149702466	8.9017970860004425	None	None	None	None	None
141	carrefor 	supermarket	None	44.4582553109318184	8.90251290053129196	None	None	None	None	None
142	jks gym\n	palestra	None	44.5107048178561442	11.3684825599193573	None	None	None	None	None
143	san siro\n	sport	None	44.460479627128862	11.3823495805263519	None	None	None	None	None
144	san matteo\n	ospedale	None	45.1950682453948858	9.17632319033145905	None	None	None	None	None
145	via ceva pv\n	supermarket	None	45.1555702307583289	9.2309839278459549	None	None	None	None	None
146	hotel Lugano	hotel	None	45.4824879948391683	9.23481713980436325	None	None	None	None	None
147	bnl	banca	None	45.4819061905595774	9.23344384878873825	None	None	None	None	None
148	carrefur\n	supermarket	None	45.4804818613106079	9.23593293875455856	None	None	None	None	None
149	città studi	universita	None	45.4803817173150762	9.2350461333990097	None	None	None	None	None
150	città studi	universita	None	45.4763520667629209	9.23356287181377411	None	Mon,Tue,Wed,Thu,Fri: 0830-1230.	None	None	None
151	sede Avis asl 3	ufficio	None	45.4794124740947154	9.23391692340373993	None	None	None	None	None
152	carrefur	supermarket	None	45.4811175129438112	9.23419218510389328	None	Mon,Tue,Wed,Thu,Fri,Sat,Sun: 0830-1330.	None	None	None
153	caldarini	farmacia	None	45.4818789220095638	9.23424918204545975	None	None	None	022666363	None
154	Lugano	hotel	None	45.4848598135456044	9.23343546688556671	None	None	None	None	None
155	via Adelchi	posta	None	45.4856695939932365	9.23160720616579056	None	None	None	None	None
156	San Paolo	banca	None	45.4861756714798346	9.23368759453296661	None	None	None	None	None
157	federico	farmacia	None	45.4055025322601793	12.3669677227735519	None	None	None	None	None
158	poste	posta	None	44.8902619773106082	8.86540520936250687	None	None	None	None	None
159	albignasego\n	supermarket	None	45.3371207095520958	11.852203868329525	None	None	None	None	None
160	Ve.Pa. 	negozio	officina - gommista	45.4610233152567034	11.8435148522257805	None	None	None	None	None
161	farmcia	farmacia	None	45.4660839829702468	11.8465832993388176	None	None	None	None	None
162	ali\n	supermarket	None	45.4653668024519035	11.8570797890424728	None	None	None	None	None
163	bennet	supermarket	None	45.5488719741762438	10.2349478378891945	campo grande	Sun: 0830-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	None	None
164	viale toscana	farmacia	None	45.5389905012425373	9.27940819412469864	viale lombardia	None	None	None	None
165	ristorante	supermarket	None	43.5555506241882355	12.1657078340649605	None	None	None	None	None
166	spezzalaaquino jjjjjjkhkhjjjjjjjkjjjjhhjjjjjjjjjjkjjjjhjjjhjjjjjjjjjjjjjjjjjjjj 	supermarket	None	-13.0745622482948356	17.6986058056354523	None	None	None	None	None
167	Gim & tonic	palestra	None	44.8219963447274594	11.6264269128441811	None	None	None	None	None
168	Ospedale 	ospedale	None	44.8218936101052847	11.6263524815440178	None	None	None	None	None
169	supermercato\n	supermarket	None	45.7518265363484886	11.761697418987751	None	None	None	None	None
170	zone pizza\n	pizzeria	None	44.4797439955912779	11.365540511906147	via roma	None	None	None	None
171	auchan	supermarket	None	40.9356775322269257	14.2453347891569138	None	None	None	None	None
172	La mala femmina	supermarket	None	43.0952400403873455	12.3123032972216606	None	None	None	None	None
173	Vieste\n	supermarket	None	41.1102708463314386	16.6843690350651741	None	None	None	None	None
174	vieste	hobby	None	41.104595918344188	16.656528040766716	None	None	None	None	None
175	Esselunga	supermarket	None	45.7120518124218052	9.32525955140590668	None	None	None	None	None
176	karkade	tabacchi	None	45.7106234799476852	9.32899955660104752	None	None	None	None	None
177	Firenze\n	supermarket	None	43.7874192189047236	11.2751242518424988	None	None	None	None	None
178	ristorante giannina\n\n\n	supermarket	None	44.1702509329691253	12.1639600396156311	None	None	None	None	None
179	\n	scuolamaterna	None	45.0790982002653209	9.5699537917971611	None	None	None	None	None
180	casa	supermarket	None	45.7491110726902832	12.3239320144057274	None	None	None	None	None
181	madre teresa di calcutta\n\n\n	scuolamaterna	None	41.8878526913014966	12.5645747780799866	None	None	None	None	None
182	pippis \n	supermarket	None	44.6108929977296356	10.550738051533699	None	None	None	None	None
183	posta	posta	None	39.2604935823764194	9.1373845562338829	None	None	None	None	None
184	farmacia	farmacia	None	39.2606926926173685	9.13733895868062973	None	None	None	None	None
185	Taccani	farmacia	None	45.4059909690225965	9.55322820693254471	None	None	None	None	None
186	Comunale	farmacia	None	45.4013375840360922	9.53048408031463623	None	None	None	None	None
187	posta	posta	None	45.8278715313495226	8.82860731333494186	None	None	None	None	None
188	lidl	supermarket	None	45.5086570949579823	9.19030454009771347	None	None	None	None	None
189	sciortino	supermarket	None	44.0484244276931918	10.0154392048716545	None	None	None	None	None
190	sciortino	supermarket	None	44.0483991999999986	10.0147666999999991	None	None	None	None	None
191	rossi giovanna\n\n\n\n	supermarket	None	44.0485827516930541	10.0145074725151062	None	None	None	018764125	None
192	sanna antonio	supermarket	None	44.0484492486830987	10.0157392770051956	None	None	None	078534634	None
193	Giovanni	supermarket	None	40.3040686069054743	18.1648055836558342	None	Mon,Tue,Wed,Thu,Fri,Sat: 0830-1230.	01-01, 01-06, P, LA, 04-25, 05-01, 06-02, 08-15, 11-01, 12-08, 12-25, 12-26: .	None	None
194	d	farmacia	None	40.302781967181069	18.1608476489782333	None	None	None	None	None
195	wi	wifi	None	40.3006683678925555	18.1602069362998009	None	None	None	None	None
196	281475111903	posta	None	40.3028154630807691	18.1593241542577744	None	None	None	None	None
197	ipercoop	supermarket	None	40.304687115968413	18.177000917494297	None	None	None	None	None
198	la stadera	supermarket	None	46.1169906958921985	12.153964452445507	None	None	None	None	None
199	casa nostra	hobby	None	45.1913102866476208	9.16622266173362732	None	None	None	None	None
200	Graziella	supermarket	None	41.8874425200000005	12.5187800500000002	None	None	None	None	None
201	ristoranti\n	ristorante	giapponese	41.03341839672661	14.3180243298411369	salerno	None	None	None	None
202	san cipirello	supermarket	None	37.9598320999999999	13.1779671999999994	None	None	None	None	None
203	\n	banca	None	45.0197505455400417	7.47551366686820895	None	None	None	None	None
204	penny\n\n	supermarket	None	43.7841731333666004	10.682189092040062	None	None	None	None	None
205	Bar tabacchi 	tabacchi	Bar	43.1434921827316487	12.2125247865915298	Viale Umbria 	None	None	None	None
206	Bar tabacchi 	bar	None	43.1435445339604584	12.2125616669654846	None	None	None	None	None
207	farmacia	farmacia	None	43.8047808828341871	10.6737760081887245	None	None	None	None	None
208	lidl	supermarket	None	45.1140076975948858	7.61509515345096588	None	None	None	None	None
209	Cia	supermarket	None	41.4573789584689081	12.8948009759187698	None	None	None	None	None
210	OK	farmacia	None	45.7055630999999991	9.74013240000000025	None	None	None	None	None
211	casa	hobby	None	45.1152445999999969	7.61275600000000008	None	None	None	None	None
212	 crai\n	supermarket	None	45.842807798208014	12.2821961715817451	None	None	None	None	None
213	Conad Margherita	supermarket	None	43.8992445670979663	12.7465559542179108	None	Mon,Tue,Fri,Sat: 0730-1930.	None	None	None
214	\n	ristorante	None	44.4935888217042361	11.3520241901278496	None	None	None	None	None
215	ldil\n	supermarket	None	45.0846634600000016	9.36266582999999919	None	None	None	None	None
216	arluno, via privata dei platani, 14	supermarket	cameretta di samuel\n	45.5050583000000017	8.9338507000000007	@teresa	None	None	02-4577588888758454775	\n
217	tabacchi\n	tabacchi	None	43.2923439991217975	10.4890522733330727	None	None	None	None	None
218	super spaccio alimentare	supermarket	None	36.8598102986485969	14.7621545568108576	None	None	None	None	None
219	lll	supermarket	None	46.1152829249449709	13.2080414146184921	None	None	None	None	None
220	Farmacie 	supermarket	None	41.1414365614293374	13.8591670989990234	None	None	None	None	None
221	Pippo	farmacia	None	41.1412426470151118	13.8597672432661057	None	None	None	None	None
222	Casa mondragone 	hotel	None	41.1405533333333366	13.8589800000000007	Viale Emilio Morelli 22	None	None	None	None
223	\n	banca	None	40.9178095551354275	17.0238947868347168	None	None	None	None	None
\.


--
-- Name: waiting_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('waiting_id_seq', 223, true);


--
-- Name: locations_pkey; Type: CONSTRAINT; Schema: public; Owner: admin; Tablespace: 
--

ALTER TABLE ONLY locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (id);


--
-- Name: suggest_pkey; Type: CONSTRAINT; Schema: public; Owner: admin; Tablespace: 
--

ALTER TABLE ONLY suggest
    ADD CONSTRAINT suggest_pkey PRIMARY KEY (id);


--
-- Name: waiting_pkey; Type: CONSTRAINT; Schema: public; Owner: admin; Tablespace: 
--

ALTER TABLE ONLY waiting
    ADD CONSTRAINT waiting_pkey PRIMARY KEY (id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

